
import React from 'react';

export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  description: string;
  icon: string;
}

export interface CloudFile {
  id: string;
  name: string;
  type: string;
  size: number; // in bytes
  uploadDate: string;
  category: 'document' | 'image' | 'other';
}

export interface User {
  id: string;
  name: string;
  phone: string;
  email?: string;
  isVerified?: boolean;
  isTrustedAgent?: boolean;
  is2FAEnabled?: boolean;
  password?: string;
  profilePicture?: string;
  securityQuestion?: string;
  securityAnswer?: string;
  role: 'user' | 'admin';
  joinedDate: string;
  storageUsed: number; // in bytes
  files: CloudFile[];
  language?: 'bn' | 'en';
}

export interface ToDo {
  id: string;
  task: string;
  targetPhone: string;
  status: 'todo' | 'doing' | 'done';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'payment' | 'work' | 'alert' | 'system';
  timestamp: string;
  targetPhone: string;
  isRead: boolean;
}

export interface AdminAccount {
  id: string;
  email?: string;
  isVerified?: boolean;
  password?: string;
  securityQuestion?: string;
  securityAnswer?: string;
}

export interface AppAlert {
  id: string;
  message: string;
  type: 'info' | 'warning' | 'success';
  priority: 'low' | 'medium' | 'high';
  date: string;
  active: boolean;
}

export interface Feedback {
  id: string;
  name: string;
  service: string;
  rating: number;
  comment: string;
  date: string;
  status: 'approved' | 'pending';
}

export enum AppView {
  USER = 'USER',
  ADMIN = 'ADMIN'
}

// Fixed: Added DocStatus type to resolve error in OfficeTools.tsx
export type DocStatus = 'draft' | 'recheck' | 'verified';

// Fixed: Added ShopHeader interface to resolve error in OfficeTools.tsx
export interface ShopHeader {
  name: string;
  address: string;
  phone: string;
  showLogo: boolean;
}

export interface OfficeDoc {
  id: string;
  title: string;
  type: 'excel' | 'word';
  lastModified: string;
  content: any; 
  isDeployed?: boolean;
  targetPhone?: string; 
  // Fixed: Updated to use DocStatus type
  status: DocStatus;
  // Fixed: Added header property to resolve error in OfficeTools.tsx line 48
  header?: ShopHeader;
}

export interface ManualApplication {
  id: string;
  customerName: string;
  phone: string;
  applicationType: string;
  trackingId: string;
  status: 'Pending' | 'Processing' | 'Success';
  date: string;
  source: 'digital' | 'manual' | 'scan';
  fileData?: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  timestamp: string;
}
