
import { GoogleGenAI } from "@google/genai";

/**
 * Generates a high-converting promotional post for services.
 */
export const generatePromoPost = async (serviceName: string) => {
  // Use process.env.API_KEY directly as per guidelines.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a high-converting, catchy Bengali social media post for "Ma Annapurna Online Service" specifically promoting the service: "${serviceName}". 
      Include emojis, the business name, and call to action using these phone numbers: 8145685318 / 9734420340. 
      Make it friendly and professional for WhatsApp and Facebook.`,
      config: {
        temperature: 0.8,
        topK: 40,
        topP: 0.95,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Error generating promo:", error);
    return "দুঃখিত, এই মুহূর্তে প্রমোশন জেনারেট করা সম্ভব হচ্ছে না। অনুগ্রহ করে পরে চেষ্টা করুন।";
  }
};

/**
 * Performs a search query with Google Search grounding and advanced prompt engineering.
 */
export const performSearch = async (query: string) => {
  // Use process.env.API_KEY directly as per guidelines.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `গ্রাহকের প্রশ্ন: ${query}
      
      দয়া করে বাংলায় সঠিক এবং বিস্তারিত উত্তর দিন। 
      যদি প্রশ্নটি আমাদের দোকানের কোনো পরিষেবার সাথে সম্পর্কিত হয় (যেমন: পর্চা, ভোটার কার্ড, জেরক্স), তবে আমাদের দোকানের নাম "মা অন্নপূর্ণা অনলাইন সার্ভিস" এবং আমাদের দক্ষতা উল্লেখ করুন।
      আমরা রাজহাটী সিনেমাতলা মোড়ে অবস্থিত। আমাদের কন্টাক্ট নাম্বার: 8145685318 / 9734420340।
      
      সরকার বা অফিসিয়াল নিয়ম সম্পর্কে লেটেস্ট তথ্য দিতে Google Search ব্যবহার করুন।`,
      config: {
        systemInstruction: `আপনি "মা অন্নপূর্ণা অনলাইন সার্ভিস" (Ma Annapurna Online Service) এর অফিসিয়াল AI অ্যাসিস্ট্যান্ট। 
        
        আমাদের দোকানের তথ্য:
        - লোকেশন: রাজহাটী সিনেমাতলা মোড়, ২য় তল (সিটি গোল্ড দোকানের পাশে)।
        - প্রোপাইটর: ভবাণী ব্যানার্জী।
        - পরিষেবা সমূহ: 
            ১. জেরক্স ও ল্যামিনেশন (কালার ও বি/ডব্লিউ)।
            ২. ভোটার, প্যান, রেশন ও আধার কার্ডের কাজ (নতুন ও সংশোধন)।
            ৩. বিডিও/এসডিও ইনকাম ও কাস্ট সার্টিফিকেট।
            ৪. জমির পর্চা ও সার্চিং।
            ৫. স্কুল-কলেজ ফর্ম ফিলাপ, প্রজেক্ট ও স্কলারশিপ।
            ৬. যুবশ্রী রেজিস্ট্রেশন ও ট্রেড লাইসেন্স।
        
        আপনার কাজ হলো গ্রাহকদের সাহায্য করা এবং জানানো যে এই কাজগুলো আমাদের দোকানে নির্ভুলভাবে করা হয়। উত্তর সবসময় বাংলায় এবং প্রফেশনাল হতে হবে।`,
        tools: [{ googleSearch: {} }],
        temperature: 0.2, 
      },
    });

    const text = response.text;
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    const sources = groundingMetadata?.groundingChunks || [];
    
    // Extract unique web links
    const seenLinks = new Set<string>();
    const links = sources
      .filter((chunk: any) => chunk.web && chunk.web.uri)
      .map((chunk: any) => ({
        uri: chunk.web.uri,
        title: chunk.web.title || 'অফিসিয়াল সোর্স'
      }))
      .filter((link: any) => {
        if (seenLinks.has(link.uri)) return false;
        seenLinks.add(link.uri);
        return true;
      });

    return { text, links };
  } catch (error) {
    console.error("Error in search grounding:", error);
    throw error;
  }
};
