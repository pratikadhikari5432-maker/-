
import React, { useState, useRef, useEffect } from 'react';
// Added Smartphone to the lucide-react imports to fix the error on line 166
import { Upload, Scan, X, CheckCircle, Camera, FileIcon, Trash2, ClipboardList, User as UserIcon, Bookmark, Phone, Download, Search, CheckSquare, Clock, AlertCircle, Eye, Printer, FileText, Scale, Users, Smartphone } from 'lucide-react';
import { ManualApplication, User } from '../types';

const ContentManager: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'upload' | 'manual'>('upload');
  const [isScanning, setIsScanning] = useState(false);
  const [flash, setFlash] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedApp, setSelectedApp] = useState<ManualApplication | null>(null);
  
  const [verifiedUsers, setVerifiedUsers] = useState<User[]>([]);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const [applications, setApplications] = useState<ManualApplication[]>(() => {
    const saved = localStorage.getItem('ma_all_applications');
    return saved ? JSON.parse(saved) : [];
  });

  const [manualForm, setManualForm] = useState({
    name: '',
    phone: '',
    type: 'ভোটার কার্ড',
    trackId: '',
    status: 'Pending' as any
  });

  useEffect(() => {
    localStorage.setItem('ma_all_applications', JSON.stringify(applications));
    const savedUsers = JSON.parse(localStorage.getItem('ma_users') || '[]');
    setVerifiedUsers(savedUsers);
  }, [applications]);

  const startScan = async () => {
    setIsScanning(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      alert("ক্যামেরা এক্সেস করা সম্ভব হচ্ছে না।");
      setIsScanning(false);
    }
  };

  const capturePhoto = () => {
    setFlash(true);
    setTimeout(() => setFlash(false), 150);
    
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0);
      
      const base64Data = canvas.toDataURL('image/jpeg');
      
      const newApp: ManualApplication = {
        id: Date.now().toString(),
        customerName: `স্ক্যান করা ডকুমেন্ট ${applications.length + 1}`,
        phone: manualForm.phone || 'N/A',
        applicationType: 'ডকুমেন্ট স্ক্যান',
        trackingId: `SCN-${Math.floor(1000 + Math.random() * 9000)}`,
        status: 'Success',
        date: new Date().toLocaleDateString('bn-BD'),
        source: 'scan',
        fileData: base64Data
      };

      setApplications([newApp, ...applications]);
      const stream = video.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      setIsScanning(false);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const app: ManualApplication = {
      id: Date.now().toString(),
      customerName: manualForm.name,
      phone: manualForm.phone,
      applicationType: manualForm.type,
      trackingId: manualForm.trackId || `MA-${Math.floor(1000 + Math.random() * 9000)}`,
      status: manualForm.status,
      date: new Date().toLocaleDateString('bn-BD'),
      source: 'manual'
    };
    setApplications([app, ...applications]);
    setManualForm({ name: '', phone: '', type: 'ভোটার কার্ড', trackId: '', status: 'Pending' });
    alert('সফলভাবে গ্রাহকের অ্যাকাউন্টে যুক্ত হয়েছে!');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files;
    if (uploaded) {
      const newApps: ManualApplication[] = Array.from(uploaded).map((f: File) => ({
        id: Math.random().toString(36).substr(2, 9),
        customerName: f.name,
        phone: manualForm.phone || 'N/A',
        applicationType: 'ডিজিটাল ফাইল',
        trackingId: `FLD-${Math.floor(1000 + Math.random() * 9000)}`,
        status: 'Success',
        date: new Date().toLocaleDateString('bn-BD'),
        source: 'digital'
      }));
      setApplications([...newApps, ...applications]);
      alert(`${uploaded.length}টি ফাইল গ্রাহকের অ্যাকাউন্টে যুক্ত হয়েছে!`);
    }
  };

  const updateStatus = (id: string, status: any) => {
    const updated = applications.map(app => app.id === id ? { ...app, status } : app);
    setApplications(updated);
    if (selectedApp?.id === id) {
        setSelectedApp({ ...selectedApp, status });
    }
    // Update local storage explicitly
    localStorage.setItem('ma_all_applications', JSON.stringify(updated));
    window.dispatchEvent(new StorageEvent('storage', { key: 'ma_all_applications', newValue: JSON.stringify(updated) }));
  };

  const deleteApp = (id: string) => {
    if (window.confirm('এই রেকর্ডটি ডিলিট করতে চান?')) {
      const updated = applications.filter(app => app.id !== id);
      setApplications(updated);
      if (selectedApp?.id === id) setSelectedApp(null);
    }
  };

  const downloadAppInfo = (app: ManualApplication) => {
    const content = `মা অন্নপূর্ণা অনলাইন সার্ভিস\nআবেদনপত্রের তথ্য\n--------------------------\nতারিখ: ${app.date}\nট্র্যাকিং আইডি: ${app.trackingId}\nগ্রাহক: ${app.customerName}\nফোন: ${app.phone}\nধরণ: ${app.applicationType}\nস্ট্যাটাস: ${app.status}\nসোর্স: ${app.source}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${app.trackingId}_${app.customerName}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredApps = applications.filter(app => 
    app.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.trackingId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.phone.includes(searchTerm)
  );

  return (
    <div className="space-y-8 animate-in fade-in">
      <canvas ref={canvasRef} className="hidden" />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-[2.5rem] border shadow-xl">
             <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2"><Users size={12}/> মালিক নির্বাচন (Owner Selection)</h3>
             <div className="relative">
                <div 
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className={`w-full p-4 border rounded-2xl flex items-center justify-between cursor-pointer transition-all ${manualForm.phone ? 'bg-amber-50 border-amber-500' : 'bg-slate-50 border-slate-200'}`}
                >
                  <div className="flex items-center gap-3">
                    <Smartphone size={18} className={manualForm.phone ? 'text-amber-600' : 'text-slate-300'} />
                    <span className="text-sm font-bold bengali-font">
                      {manualForm.phone ? `${verifiedUsers.find(u => u.phone === manualForm.phone)?.name || manualForm.phone}` : 'গ্রাহক সিলেক্ট করুন'}
                    </span>
                  </div>
                  <Search size={16} className="text-slate-300" />
                </div>
                
                {isUserMenuOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border rounded-2xl shadow-2xl z-[60] overflow-hidden animate-in zoom-in-95">
                    <div className="p-3 border-b bg-slate-50">
                      <input 
                        type="tel" 
                        placeholder="নাম বা ফোন দিয়ে সার্চ..." 
                        className="w-full p-3 bg-white border rounded-xl outline-none text-xs font-bold"
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="max-h-60 overflow-y-auto custom-scrollbar">
                      {verifiedUsers.filter(u => u.phone.includes(searchTerm) || u.name.toLowerCase().includes(searchTerm.toLowerCase())).map(u => (
                        <div 
                          key={u.id} 
                          onClick={() => { setManualForm({...manualForm, phone: u.phone, name: u.name}); setIsUserMenuOpen(false); }}
                          className="p-4 hover:bg-amber-50 cursor-pointer border-b last:border-0"
                        >
                          <p className="text-sm font-black text-slate-800">{u.name}</p>
                          <p className="text-[10px] text-slate-400 font-bold">{u.phone}</p>
                        </div>
                      ))}
                      {verifiedUsers.length === 0 && <div className="p-10 text-center text-xs opacity-30">No users found.</div>}
                    </div>
                    <div onClick={() => { setManualForm({...manualForm, phone: '', name: ''}); setIsUserMenuOpen(false); }} className="p-3 bg-slate-50 border-t text-center text-[10px] font-black text-rose-500 cursor-pointer uppercase tracking-widest">Clear Assignment</div>
                  </div>
                )}
             </div>
          </div>

          <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm w-full">
            <button onClick={() => setActiveTab('upload')} className={`flex-1 px-4 py-3 rounded-xl flex items-center justify-center gap-2 text-sm font-bold transition-all bengali-font ${activeTab === 'upload' ? 'bg-amber-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>
              <Scan size={16} /> স্ক্যান ও আপলোড
            </button>
            <button onClick={() => setActiveTab('manual')} className={`flex-1 px-4 py-3 rounded-xl flex items-center justify-center gap-2 text-sm font-bold transition-all bengali-font ${activeTab === 'manual' ? 'bg-amber-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>
              <ClipboardList size={16} /> ম্যানুয়াল এন্ট্রি
            </button>
          </div>

          {activeTab === 'upload' ? (
            <div className="space-y-4">
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-xl text-center group">
                 <label className={`block cursor-pointer ${!manualForm.phone ? 'opacity-50 grayscale' : ''}`}>
                    <input type="file" multiple className="hidden" onChange={handleFileUpload} disabled={!manualForm.phone} />
                    <div className="w-16 h-16 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600 mx-auto mb-4 group-hover:scale-110 transition-transform"><Upload size={32} /></div>
                    <h4 className="font-black text-slate-800 text-lg bengali-font">ফাইল আপলোড</h4>
                    <p className="text-xs text-slate-400 mt-1 bengali-font">{manualForm.phone ? 'গ্রাহকের জন্য ফাইল নির্বাচন করুন' : 'আগে গ্রাহক নির্বাচন করুন'}</p>
                 </label>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-xl text-center group relative overflow-hidden">
                {!isScanning ? (
                  <button onClick={() => manualForm.phone ? startScan() : alert('আগে গ্রাহক নির্বাচন করুন')} className={`w-full ${!manualForm.phone ? 'opacity-50' : ''}`}>
                    <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mx-auto mb-4 group-hover:scale-110 transition-transform"><Camera size={32} /></div>
                    <h4 className="font-black text-slate-800 text-lg bengali-font">ক্যামেরা স্ক্যান</h4>
                    <p className="text-xs text-slate-400 mt-1 bengali-font">সরাসরি ছবি তুলে পাঠান</p>
                  </button>
                ) : (
                  <div className="relative h-64 rounded-2xl overflow-hidden bg-black ring-4 ring-blue-100">
                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                    {flash && <div className="absolute inset-0 bg-white z-50 animate-out fade-out"></div>}
                    <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-3">
                      <button onClick={capturePhoto} className="bg-amber-600 text-white p-4 rounded-full shadow-2xl active:scale-95 transition-all"><Camera size={24} /></button>
                      <button onClick={() => setIsScanning(false)} className="bg-white/20 backdrop-blur-md text-white p-4 rounded-full hover:bg-rose-500 transition-all"><X size={24} /></button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-xl">
               <h3 className="font-black text-slate-800 mb-6 text-xl bengali-font">নতুন অ্যাপ্লিকেশন</h3>
               <form onSubmit={handleManualSubmit} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 bengali-font">গ্রাহকের নাম</label>
                    <input type="text" required placeholder="পুরো নাম" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none bengali-font" value={manualForm.name} onChange={e => setManualForm({...manualForm, name: e.target.value})} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 bengali-font">ফোন নাম্বার</label>
                    <input type="tel" required placeholder="মোবাইল নাম্বার" className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none" value={manualForm.phone} onChange={e => setManualForm({...manualForm, phone: e.target.value})} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 bengali-font">পরিষেবার ধরণ</label>
                    <select className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-amber-500 text-sm bengali-font" value={manualForm.type} onChange={e => setManualForm({...manualForm, type: e.target.value})}>
                      <option>ভোটার কার্ড</option>
                      <option>প্যান কার্ড</option>
                      <option>জমির মিউটেশন</option>
                      <option>রেজিস্ট্রি ও দলিল</option>
                      <option>দানপত্র দলিল</option>
                      <option>জমির পর্চা</option>
                      <option>রেশন কার্ড</option>
                      <option>স্কলারশিপ</option>
                    </select>
                  </div>
                  <button type="submit" className="w-full bg-slate-900 text-white py-5 rounded-xl font-black shadow-lg hover:bg-black transition-all mt-4 bengali-font">সরাসরি অ্যাকাউন্টে পাঠান</button>
               </form>
            </div>
          )}
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm flex items-center">
            <Search className="text-slate-300 ml-3" size={24} />
            <input type="text" placeholder="নাম, আইডি বা ফোন দিয়ে খুঁজুন..." className="w-full p-3 bg-transparent outline-none text-lg bengali-font" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </div>
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-2xl overflow-hidden min-h-[500px]">
             <div className="p-8 border-b border-slate-50 flex items-center justify-between"><h3 className="font-black text-xl text-slate-800 flex items-center gap-3 bengali-font"><CheckSquare className="text-amber-500" /> অ্যাপ্লিকেশন ট্র্যাকার (Shared Logic)</h3></div>
             <div className="divide-y divide-slate-50 max-h-[700px] overflow-y-auto custom-scrollbar">
                {filteredApps.map(app => (
                  <div key={app.id} className="p-6 flex flex-col md:flex-row md:items-center justify-between hover:bg-slate-50/50 transition-colors gap-4">
                     <div className="flex items-center gap-5">
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm ${app.source === 'scan' ? 'bg-blue-50 text-blue-600' : app.source === 'manual' ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'}`}>
                           {app.source === 'scan' ? <Camera size={28} /> : app.source === 'manual' ? <UserIcon size={28} /> : (app.applicationType.includes('দলিল') || app.applicationType.includes('রেজিস্ট্রি')) ? <Scale size={28} /> : <FileIcon size={28} />}
                        </div>
                        <div>
                           <div className="flex items-center gap-2">
                             <p className="font-black text-slate-800 text-lg bengali-font">{app.customerName}</p>
                             <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-widest bengali-font ${app.status === 'Success' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>{app.status === 'Success' ? 'সফল' : 'পেন্ডিং'}</span>
                           </div>
                           <p className="text-xs text-slate-400 font-bold">আইডি: {app.trackingId} • ফোন: <span className="text-amber-600">{app.phone}</span> • {app.date}</p>
                           <p className="text-[10px] text-slate-300 font-bold uppercase tracking-widest mt-1 bengali-font">{app.applicationType}</p>
                        </div>
                     </div>
                     <div className="flex items-center gap-3">
                        <button onClick={() => setSelectedApp(app)} className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-amber-600 transition-all shadow-sm bengali-font"><Eye size={16} /> রিচেক</button>
                        <button onClick={() => downloadAppInfo(app)} className="p-2.5 bg-slate-900 text-white rounded-xl hover:bg-black transition-all shadow-md"><Download size={18} /></button>
                        <button onClick={() => deleteApp(app.id)} className="p-2.5 bg-white border border-slate-200 text-slate-300 hover:text-rose-500 rounded-xl transition-all"><Trash2 size={18} /></button>
                     </div>
                  </div>
                ))}
                {filteredApps.length === 0 && <div className="p-20 text-center opacity-30 bengali-font">কোনো রেকর্ড খুঁজে পাওয়া যায়নি।</div>}
             </div>
          </div>
        </div>
      </div>

      {selectedApp && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-md animate-in fade-in">
           <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden relative">
              <button onClick={() => setSelectedApp(null)} className="absolute top-8 right-8 p-2 bg-slate-100 rounded-full text-slate-400 hover:text-rose-500 z-10"><X size={24} /></button>
              <div className="flex flex-col md:flex-row h-full">
                <div className="p-10 flex-grow space-y-8">
                   <div>
                      <h2 className="text-3xl font-black text-slate-900 mb-2 bengali-font">{selectedApp.customerName}</h2>
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest bengali-font"><span>আবেদনপত্রের বিস্তারিত</span><div className="w-1.5 h-1.5 rounded-full bg-slate-300"></div><span>#{selectedApp.trackingId}</span></div>
                   </div>
                   <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-1"><label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 bengali-font">ফোন</label><p className="font-bold text-slate-800">{selectedApp.phone}</p></div>
                      <div className="space-y-1"><label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 bengali-font">ধরণ</label><p className="font-bold text-slate-800 bengali-font">{selectedApp.applicationType}</p></div>
                      <div className="space-y-1"><label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 bengali-font">তারিখ</label><p className="font-bold text-slate-800">{selectedApp.date}</p></div>
                      <div className="space-y-1"><label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 bengali-font">স্ট্যাটাস</label>
                        <select className={`text-xs font-bold px-3 py-1.5 rounded-lg border-none outline-none bengali-font ${selectedApp.status === 'Success' ? 'bg-emerald-50 text-emerald-600' : selectedApp.status === 'Processing' ? 'bg-blue-50 text-blue-600' : 'bg-rose-50 text-rose-600'}`} value={selectedApp.status} onChange={(e) => updateStatus(selectedApp.id, e.target.value)}>
                            <option value="Pending">পেন্ডিং</option><option value="Processing">প্রসেসিং</option><option value="Success">সফল</option>
                        </select>
                      </div>
                   </div>
                   <div className="pt-8 border-t border-slate-100 flex gap-4">
                      <button onClick={() => downloadAppInfo(selectedApp)} className="flex-1 bg-amber-600 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2 shadow-lg hover:bg-amber-700 transition-all bengali-font"><Download size={20} /> ডাউনলোড</button>
                      <button onClick={() => window.print()} className="p-4 bg-slate-100 text-slate-600 rounded-2xl hover:bg-slate-200 transition-all"><Printer size={20} /></button>
                   </div>
                </div>
                <div className="md:w-72 bg-slate-50 border-l border-slate-100 flex flex-col">
                  <div className="p-6 border-b border-slate-200"><h4 className="text-[10px] font-black uppercase text-slate-400 tracking-widest bengali-font">প্রিভিউ</h4></div>
                  <div className="flex-grow p-6 flex items-center justify-center">
                    {selectedApp.fileData ? (
                      <img src={selectedApp.fileData} alt="Doc" className="w-full h-full object-contain rounded-xl" />
                    ) : (
                      <div className="text-center opacity-30"><FileText size={48} className="mx-auto mb-4" /><p className="text-[10px] font-bold uppercase tracking-widest bengali-font">প্রিভিউ নেই</p></div>
                    )}
                  </div>
                </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default ContentManager;
