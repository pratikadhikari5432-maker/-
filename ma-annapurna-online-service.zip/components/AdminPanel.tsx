
import React, { useState, useEffect } from 'react';
import { Users, TrendingUp, Bell, ClipboardList, LogOut, Phone, Send, Activity, ListTodo, Shield, Smartphone, MessageSquare, CheckCircle, Search, Settings, Inbox, FileText, Share2, Trash2, Download } from 'lucide-react';
import OfficeTools from './OfficeTools.tsx';
import ContentManager from './ContentManager.tsx';
import ShopUtilities from './ShopUtilities.tsx';
import { User, ToDo, AppNotification, ManualApplication, OfficeDoc } from '../types.ts';

interface AdminPanelProps {
  onLogout: () => void;
  lang?: 'bn' | 'en';
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onLogout, lang = 'bn' }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'todo' | 'office' | 'utilities' | 'content' | 'inbox'>('dashboard');
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [adminMsg, setAdminMsg] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [sharedInbox, setSharedInbox] = useState<any[]>([]);
  const [botInstruction, setBotInstruction] = useState(() => localStorage.getItem('ma_bot_tip') || '');

  useEffect(() => {
    const savedUsers = JSON.parse(localStorage.getItem('ma_users') || '[]');
    setUsers(savedUsers);
    
    const inbox = JSON.parse(localStorage.getItem('ma_user_shared_inbox') || '[]');
    setSharedInbox(inbox);

    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'ma_user_shared_inbox') {
        setSharedInbox(JSON.parse(e.newValue || '[]'));
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [activeTab]);

  const sendNotification = (targetPhone: string, title: string, message: string) => {
    if (!message.trim()) {
      alert('অনুগ্রহ করে একটি বার্তা লিখুন।');
      return;
    }
    const notifications: AppNotification[] = JSON.parse(localStorage.getItem('ma_notifications') || '[]');
    const newNotif: AppNotification = {
      id: Date.now().toString(),
      title,
      message,
      type: 'alert',
      timestamp: new Date().toLocaleString('bn-BD'),
      targetPhone,
      isRead: false
    };
    const updatedNotifs = [newNotif, ...notifications];
    localStorage.setItem('ma_notifications', JSON.stringify(updatedNotifs));
    
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'ma_notifications',
      newValue: JSON.stringify(updatedNotifs)
    }));
    
    alert('নোটিফিকেশন পাঠানো হয়েছে!');
    setAdminMsg('');
  };

  const deleteInboxItem = (id: string) => {
    const updated = sharedInbox.filter(item => item.id !== id);
    setSharedInbox(updated);
    localStorage.setItem('ma_user_shared_inbox', JSON.stringify(updated));
  };

  const handleUpdateBotTip = () => {
    localStorage.setItem('ma_bot_tip', botInstruction);
    window.dispatchEvent(new StorageEvent('storage', { key: 'ma_bot_tip', newValue: botInstruction }));
    alert('চ্যাটবট আপডেট করা হয়েছে!');
  };

  const t = {
    overview: lang === 'bn' ? 'ওভারভিউ' : 'Overview',
    users: lang === 'bn' ? 'গ্রাহক কন্ট্রোল' : 'Users Control',
    todo: lang === 'bn' ? 'টু-ডু লিস্ট' : 'To-Do List',
    inbox: lang === 'bn' ? 'ইউজার ইনবক্স' : 'User Inbox',
    logout: lang === 'bn' ? 'লগআউট' : 'Logout'
  };

  return (
    <div className={`bg-slate-50 min-h-screen pb-20 ${lang === 'bn' ? 'bengali-font' : ''}`}>
      <div className="bg-white border-b sticky top-16 z-40 overflow-x-auto scrollbar-hide shadow-sm">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <div className="flex space-x-6">
            {[
              { id: 'dashboard', label: t.overview, icon: <TrendingUp size={18} /> },
              { id: 'inbox', label: t.inbox, icon: <Inbox size={18} />, count: sharedInbox.length },
              { id: 'users', label: t.users, icon: <Users size={18} /> },
              { id: 'office', label: 'MS টুলস', icon: <ClipboardList size={18} /> },
              { id: 'content', label: 'কন্টেন্ট', icon: <Activity size={18} /> },
              { id: 'utilities', label: 'ইউটিলিটি', icon: <Shield size={18} /> },
            ].map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`py-5 px-1 text-sm font-bold flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap relative ${activeTab === tab.id ? 'border-slate-900 text-slate-900' : 'border-transparent text-slate-500 hover:text-slate-900'}`}>
                {tab.icon}<span>{tab.label}</span>
                {tab.count !== undefined && tab.count > 0 && (
                  <span className="absolute -top-1 -right-3 bg-rose-500 text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-pulse">{tab.count}</span>
                )}
              </button>
            ))}
          </div>
          <button onClick={onLogout} className="text-slate-400 hover:text-rose-500 flex items-center gap-2 font-bold text-xs py-5 transition-colors shrink-0"><LogOut size={16} /> {t.logout}</button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in">
             <div className="lg:col-span-2 bg-white p-8 rounded-[3rem] border shadow-sm">
                <h3 className="text-xl font-black mb-6 flex items-center gap-2"><Settings className="text-amber-500" /> চ্যাটবট কন্ট্রোল</h3>
                <textarea 
                  className="w-full p-6 bg-slate-50 border rounded-3xl outline-none focus:ring-2 focus:ring-amber-500 mb-4 h-32 bengali-font font-bold"
                  placeholder="যেমন: আজ সার্ভার ডাউন থাকতে পারে বা নতুন রেশন কার্ডের আপডেট..."
                  value={botInstruction}
                  onChange={e => setBotInstruction(e.target.value)}
                />
                <button onClick={handleUpdateBotTip} className="bg-slate-900 text-white px-8 py-3 rounded-2xl font-black text-sm hover:bg-black transition-all">বট আপডেট করুন</button>
             </div>
             
             <div className="bg-slate-900 p-8 rounded-[3rem] text-white flex flex-col justify-center items-center text-center space-y-4">
                <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center text-slate-900"><Activity size={32}/></div>
                <h3 className="text-2xl font-black">অ্যাডমিন একটিভ</h3>
                <p className="text-slate-400 bengali-font text-sm">{users.length} ভেরিফাইড গ্রাহক বর্তমানে সিস্টেমের সাথে যুক্ত।</p>
             </div>
          </div>
        )}

        {activeTab === 'inbox' && (
          <div className="bg-white rounded-[2.5rem] border shadow-xl overflow-hidden animate-in slide-in-from-bottom-4">
            <div className="p-8 border-b flex items-center justify-between">
              <h3 className="text-xl font-black flex items-center gap-3"><Inbox className="text-amber-500" /> গ্রাহকদের পাঠানো ফাইল (Inbox)</h3>
              <p className="text-xs font-bold text-slate-400 uppercase">Recent Transfers</p>
            </div>
            <div className="divide-y divide-slate-50">
              {sharedInbox.length === 0 && <div className="p-20 text-center opacity-30 font-bold">No shared files in inbox.</div>}
              {sharedInbox.map(item => (
                <div key={item.id} className="p-8 flex items-center justify-between hover:bg-slate-50 transition-colors group">
                  <div className="flex items-center gap-6">
                    <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center shrink-0"><FileText size={28}/></div>
                    <div>
                      <p className="font-black text-lg text-slate-800">{item.name}</p>
                      <p className="text-xs text-amber-600 font-black bengali-font">গ্রাহক: {item.ownerName} • {item.ownerPhone}</p>
                      <p className="text-[10px] text-slate-300 font-bold uppercase mt-1">Shared at: {item.sharedAt}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button className="p-3 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-600 shadow-sm"><Download size={18}/></button>
                    <button onClick={() => deleteInboxItem(item.id)} className="p-3 bg-rose-50 text-rose-500 rounded-xl hover:bg-rose-100 transition-colors"><Trash2 size={18}/></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
             <div className="lg:col-span-2 bg-white rounded-[2.5rem] border shadow-xl overflow-hidden p-10">
                <div className="flex items-center justify-between mb-8">
                   <h3 className="text-xl font-black flex items-center gap-3"><Users className="text-amber-500" /> গ্রাহক তালিকা ও ওনারশিপ</h3>
                   <div className="relative w-64">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                      <input type="text" placeholder="নাম বা ফোন..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl outline-none text-xs" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                   </div>
                </div>
                <div className="space-y-4 max-h-[600px] overflow-y-auto pr-4 custom-scrollbar">
                   {users.filter(u => u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.phone.includes(searchTerm)).map(u => (
                     <div key={u.id} onClick={() => setSelectedUser(u)} className={`p-6 rounded-3xl flex items-center justify-between cursor-pointer transition-all border ${selectedUser?.id === u.id ? 'bg-amber-50 border-amber-300 shadow-md' : 'bg-slate-50 border-transparent hover:bg-slate-100'}`}>
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 bg-slate-900 text-white rounded-2xl flex items-center justify-center font-black">{u.name.charAt(0)}</div>
                           <div>
                              <p className="font-bold text-slate-800">{u.name}</p>
                              <p className="text-xs text-slate-400 flex items-center gap-1"><Smartphone size={10} /> {u.phone}</p>
                           </div>
                        </div>
                        <CheckCircle size={18} className={u.isVerified ? 'text-emerald-500' : 'text-slate-200'} />
                     </div>
                   ))}
                </div>
             </div>

             <div className="bg-white rounded-[2.5rem] p-10 border shadow-2xl h-fit sticky top-24">
                {selectedUser ? (
                  <div className="space-y-8 animate-in slide-in-from-right-4">
                     <div className="text-center">
                        <div className="w-16 h-16 bg-amber-500 text-slate-900 rounded-full flex items-center justify-center font-black text-2xl mx-auto mb-3">{selectedUser.name.charAt(0)}</div>
                        <h4 className="text-2xl font-black">{selectedUser.name}</h4>
                        <p className="text-amber-600 font-bold">{selectedUser.phone}</p>
                     </div>

                     <div className="space-y-4 pt-4 border-t">
                        <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><MessageSquare size={12}/> ব্যক্তিগত এলার্ট</h5>
                        <textarea 
                          className="w-full p-4 bg-slate-50 border rounded-2xl outline-none text-sm h-32 bengali-font" 
                          placeholder="নির্দিষ্ট কোনো বার্তা লিখুন..." 
                          value={adminMsg}
                          onChange={e => setAdminMsg(e.target.value)}
                        />
                        <button onClick={() => sendNotification(selectedUser.phone, 'অ্যাডমিন থেকে বার্তা', adminMsg)} className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black shadow-xl flex items-center justify-center gap-2 hover:bg-black transition-all">
                           <Send size={18} /> এলার্ট পাঠান
                        </button>
                     </div>
                  </div>
                ) : (
                  <div className="text-center py-20 opacity-30">
                     <Users size={64} className="mx-auto mb-4" />
                     <p className="font-black bengali-font">গ্রাহক নির্বাচন করুন</p>
                  </div>
                )}
             </div>
          </div>
        )}

        {activeTab === 'office' && <OfficeTools lang={lang} />}
        {activeTab === 'content' && <ContentManager />}
        {activeTab === 'utilities' && <ShopUtilities />}
      </div>
    </div>
  );
};

export default AdminPanel;
