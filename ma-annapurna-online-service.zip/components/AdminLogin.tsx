
import React, { useState } from 'react';
import { Lock, User, Eye, EyeOff, ShieldCheck, AlertCircle, UserPlus, CheckCircle, ArrowRight, Loader2, HelpCircle, RefreshCcw } from 'lucide-react';
import { AdminAccount } from '../types';

interface AdminLoginProps {
  onLogin: (success: boolean) => void;
  onCancel: () => void;
}

const DEFAULT_ADMIN: AdminAccount = { 
  id: 'admin', 
  email: 'admin@annapurna.com',
  isVerified: true,
  password: 'ma@2024',
  securityQuestion: 'দোকানটি কোন মোড়ে অবস্থিত?',
  securityAnswer: 'সিনেমাতলা'
};

const SECURITY_OPTIONS = [
  "দোকানটি কোন মোড়ে অবস্থিত?",
  "আপনার প্রিয় পরিষেবা কোনটি?",
  "দোকানটি কোন সালে প্রতিষ্ঠিত?",
  "আপনার প্রিয় কোড কি?"
];

const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin, onCancel }) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [forgotStep, setForgotStep] = useState<'search' | 'verify'>('search');
  const [foundAdmin, setFoundAdmin] = useState<AdminAccount | null>(null);
  
  const [formData, setFormData] = useState({ 
    id: '', 
    email: '', 
    password: '', 
    newPassword: '',
    securityQuestion: SECURITY_OPTIONS[0],
    securityAnswer: ''
  });

  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const getAdmins = (): AdminAccount[] => {
    const saved = localStorage.getItem('ma_admins_list');
    let admins: AdminAccount[] = [];
    if (!saved) {
      admins = [DEFAULT_ADMIN];
      localStorage.setItem('ma_admins_list', JSON.stringify(admins));
    } else {
      try {
        admins = JSON.parse(saved);
      } catch (e) {
        admins = [DEFAULT_ADMIN];
      }
    }
    return admins;
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    setTimeout(() => {
      const admins = getAdmins();
      const inputId = formData.id.trim().toLowerCase();
      const inputPass = formData.password;

      const found = admins.find(a => 
        (a.id.toLowerCase() === inputId || (a.email && a.email.toLowerCase() === inputId)) 
        && a.password === inputPass
      );

      if (found) {
        setSuccess('প্রবেশ সফল...');
        localStorage.setItem('ma_active_admin_id', found.id);
        localStorage.setItem('ma_admin_auth', 'true');
        setTimeout(() => onLogin(true), 800);
      } else {
        setError('ভুল আইডি বা পাসওয়ার্ড।');
        setLoading(false);
      }
    }, 600);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const admins = getAdmins();
    const cleanId = formData.id.trim().toLowerCase();

    if (admins.some(a => a.id.toLowerCase() === cleanId)) {
      setError('এই আইডিটি ইতিমধ্যে ব্যবহৃত হচ্ছে।');
      setLoading(false);
      return;
    }

    const newAdmin: AdminAccount = {
      id: formData.id.trim(),
      email: formData.email.trim(),
      isVerified: true,
      password: formData.password,
      securityQuestion: formData.securityQuestion,
      securityAnswer: formData.securityAnswer.trim().toLowerCase()
    };

    const updatedAdmins = [...admins, newAdmin];
    localStorage.setItem('ma_admins_list', JSON.stringify(updatedAdmins));
    
    // Auto-login after signup for "Instant Access"
    setSuccess('অ্যাকাউন্ট তৈরি সফল! প্রবেশ অনুমোদিত হচ্ছে...');
    localStorage.setItem('ma_active_admin_id', newAdmin.id);
    localStorage.setItem('ma_admin_auth', 'true');
    
    setTimeout(() => {
      onLogin(true);
      setLoading(false);
    }, 1500);
  };

  const handleForgotSearch = () => {
    const admins = getAdmins();
    const target = formData.id.trim().toLowerCase();
    const found = admins.find(a => a.id.toLowerCase() === target || a.email?.toLowerCase() === target);
    if (found) {
      setFoundAdmin(found);
      setForgotStep('verify');
      setError('');
    } else {
      setError('অ্যাডমিন খুঁজে পাওয়া যায়নি।');
    }
  };

  const handleResetPassword = () => {
    if (!foundAdmin) return;
    if (foundAdmin.securityAnswer?.toLowerCase() === formData.securityAnswer.trim().toLowerCase()) {
      const admins = getAdmins();
      const updated = admins.map(a => a.id === foundAdmin.id ? { ...a, password: formData.newPassword } : a);
      localStorage.setItem('ma_admins_list', JSON.stringify(updated));
      setSuccess('পাসওয়ার্ড রিসেট সফল!');
      setTimeout(() => {
        setMode('login');
        setFormData({ ...formData, id: foundAdmin.id, password: formData.newPassword });
      }, 1500);
    } else {
      setError('ভুল উত্তর!');
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 bg-slate-50">
      <div className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="bg-slate-900 p-10 text-center text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
          <div className="bg-amber-500 w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-4 rotate-3 shadow-2xl transition-transform hover:rotate-6">
            {mode === 'signup' ? <UserPlus size={32} /> : mode === 'forgot' ? <HelpCircle size={32} /> : <ShieldCheck size={32} />}
          </div>
          <h2 className="text-xl font-black bengali-font">
            {mode === 'signup' ? 'নতুন অ্যাডমিন' : mode === 'forgot' ? 'পাসওয়ার্ড উদ্ধার' : 'অ্যাডমিন পোর্টাল'}
          </h2>
          <p className="text-slate-400 text-[10px] uppercase font-bold tracking-widest opacity-80 mt-1">Authorized Access Only</p>
        </div>

        <div className="p-8">
          {error && <div className="mb-4 p-4 bg-rose-50 text-rose-600 rounded-2xl flex items-center gap-2 text-xs font-bold border border-rose-100 animate-in shake"><AlertCircle size={16} /> {error}</div>}
          {success && <div className="mb-4 p-4 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center gap-2 text-xs font-bold border border-emerald-100"><CheckCircle size={16} /> {success}</div>}

          <form onSubmit={(e) => { 
            e.preventDefault(); 
            if(mode === 'login') handleLogin(e); 
            else if(mode === 'signup') handleSignup(e);
            else forgotStep === 'search' ? handleForgotSearch() : handleResetPassword(); 
          }} className="space-y-4">
            
            {(mode !== 'forgot' || forgotStep === 'search') && (
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input type="text" placeholder="Admin ID / Email" className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border outline-none font-bold focus:ring-2 focus:ring-slate-900" value={formData.id} onChange={e => setFormData({...formData, id: e.target.value})} required />
              </div>
            )}

            {mode === 'signup' && (
              <div className="relative">
                <RefreshCcw className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input type="email" placeholder="Official Email" className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border outline-none font-bold" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} required />
              </div>
            )}

            {mode !== 'forgot' && (
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input type={showPassword ? "text" : "password"} placeholder="Password" className="w-full pl-12 pr-12 py-4 rounded-2xl bg-slate-50 border outline-none font-bold focus:ring-2 focus:ring-slate-900" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} required />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300">{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button>
              </div>
            )}

            {mode === 'signup' && (
              <div className="space-y-3 p-4 bg-slate-50 rounded-2xl border">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Recovery Security Question</p>
                <select className="w-full p-3 bg-white border rounded-xl text-xs font-bold outline-none bengali-font" value={formData.securityQuestion} onChange={e => setFormData({...formData, securityQuestion: e.target.value})}>
                  {SECURITY_OPTIONS.map(q => <option key={q} value={q}>{q}</option>)}
                </select>
                <input type="text" placeholder="প্রশ্নের উত্তর দিন" className="w-full p-3 bg-white border rounded-xl text-xs font-bold bengali-font" value={formData.securityAnswer} onChange={e => setFormData({...formData, securityAnswer: e.target.value})} required />
              </div>
            )}

            {mode === 'forgot' && forgotStep === 'verify' && foundAdmin && (
              <div className="space-y-4 animate-in slide-in-from-right-4">
                 <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200">
                    <p className="text-[10px] font-black text-amber-600 uppercase mb-2">নিরাপত্তা প্রশ্ন</p>
                    <p className="text-sm font-bold text-slate-700 bengali-font mb-3">{foundAdmin.securityQuestion}</p>
                    <input type="text" placeholder="প্রশ্নের উত্তর দিন" className="w-full p-4 rounded-xl border-none outline-none bengali-font font-bold shadow-inner" value={formData.securityAnswer} onChange={e => setFormData({...formData, securityAnswer: e.target.value})} autoFocus />
                 </div>
                 <div className="relative">
                   <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                   <input type="password" placeholder="নতুন পাসওয়ার্ড" className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border outline-none font-bold" value={formData.newPassword} onChange={e => setFormData({...formData, newPassword: e.target.value})} required />
                 </div>
              </div>
            )}
            
            <button type="submit" disabled={loading} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black shadow-xl hover:bg-black transition-all flex items-center justify-center gap-2">
              {loading ? <Loader2 className="animate-spin" size={20} /> : <>{mode === 'login' ? 'Login' : mode === 'signup' ? 'Signup' : forgotStep === 'search' ? 'Find Account' : 'Reset Password'} <ArrowRight size={20} /></>}
            </button>
          </form>

          <div className="mt-6 flex justify-between text-xs font-bold">
             <button onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); setSuccess(''); }} className="text-amber-600 hover:underline">
               {mode === 'login' ? 'New Admin?' : 'Back to Login'}
             </button>
             {mode === 'login' && (
               <button onClick={() => { setMode('forgot'); setForgotStep('search'); setError(''); }} className="text-slate-400 hover:text-amber-600">Forgot Password?</button>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
