
import React, { useState, useRef, useEffect } from 'react';
import { Camera, Scissors, PenTool, FileType, Download, Trash2, Upload, Move, Maximize2, X, Check, Crop, RefreshCw, CheckCircle, Image as ImageIcon, Plus, Printer } from 'lucide-react';

const ShopUtilities: React.FC = () => {
  const [activeTool, setActiveTool] = useState<'photo' | 'esign' | 'pdf'>('photo');
  
  // Passport Photo State
  const [photoFile, setPhotoFile] = useState<string | null>(null);
  const [photoBg, setPhotoBg] = useState<'white' | 'blue' | 'none'>('white');
  const [photoCount, setPhotoCount] = useState<4 | 8>(8);
  const [isCropping, setIsCropping] = useState(false);
  const [cropArea, setCropArea] = useState({ x: 10, y: 10, width: 80, height: 80 }); 
  const [isDraggingCrop, setIsDraggingCrop] = useState(false);
  const photoCanvasRef = useRef<HTMLCanvasElement>(null);
  const cropWorkspaceRef = useRef<HTMLDivElement>(null);

  // E-Sign State
  const signCanvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [signDoc, setSignDoc] = useState<string | null>(null);
  const [capturedSign, setCapturedSign] = useState<string | null>(null);
  const [signPos, setSignPos] = useState({ x: 50, y: 50 });
  const [signScale, setSignScale] = useState(1);
  const [isDraggingSign, setIsDraggingSign] = useState(false);
  const signWorkspaceRef = useRef<HTMLDivElement>(null);

  // PDF Tool State
  const [pdfImages, setPdfImages] = useState<string[]>([]);
  const [compressLevel, setCompressLevel] = useState(0.5);

  // --- Passport Photo Logic ---
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setPhotoFile(reader.result as string);
        setIsCropping(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const renderPhotoGrid = () => {
    if (!photoFile || !photoCanvasRef.current || isCropping) return;
    const canvas = photoCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      // Standard 4x6 inch paper at 300 DPI
      canvas.width = 1200;
      canvas.height = 1800;
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      const photoW = 350; // approx 35mm
      const photoH = 450; // approx 45mm
      const margin = 50;
      
      const sx = (cropArea.x / 100) * img.width;
      const sy = (cropArea.y / 100) * img.height;
      const sw = (cropArea.width / 100) * img.width;
      const sh = (cropArea.height / 100) * img.height;

      for (let i = 0; i < photoCount; i++) {
        const x = (i % 2) * (photoW + margin) + 225; 
        const y = Math.floor(i / 2) * (photoH + margin) + 100;
        
        ctx.fillStyle = photoBg === 'white' ? '#FFFFFF' : photoBg === 'blue' ? '#007FFF' : '#F0F0F0';
        ctx.fillRect(x, y, photoW, photoH);
        ctx.drawImage(img, sx, sy, sw, sh, x, y, photoW, photoH);
        ctx.strokeStyle = '#EEEEEE';
        ctx.strokeRect(x, y, photoW, photoH);
      }
    };
    img.src = photoFile;
  };

  useEffect(() => {
    if (activeTool === 'photo' && photoFile && !isCropping) renderPhotoGrid();
  }, [photoFile, photoBg, photoCount, activeTool, isCropping, cropArea]);

  const handleCropDrag = (e: any) => {
    if (!isCropping || !isDraggingCrop || !cropWorkspaceRef.current) return;
    const rect = cropWorkspaceRef.current.getBoundingClientRect();
    const clientX = e.clientX || (e.touches && e.touches[0].clientX);
    const clientY = e.clientY || (e.touches && e.touches[0].clientY);
    let x = ((clientX - rect.left) / rect.width) * 100;
    let y = ((clientY - rect.top) / rect.height) * 100;
    const halfW = cropArea.width / 2;
    const halfH = cropArea.height / 2;
    x = Math.max(halfW, Math.min(100 - halfW, x)) - halfW;
    y = Math.max(halfH, Math.min(100 - halfH, y)) - halfH;
    setCropArea(prev => ({ ...prev, x, y }));
  };

  // --- E-Sign Logic ---
  const startDrawing = (e: any) => {
    const canvas = signCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    setIsDrawing(true);
    const pos = getCanvasPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
  };

  const draw = (e: any) => {
    if (!isDrawing) return;
    const canvas = signCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const pos = getCanvasPos(e, canvas);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.stroke();
  };

  const getCanvasPos = (e: any, canvas: HTMLCanvasElement) => {
    const rect = canvas.getBoundingClientRect();
    const clientX = e.clientX || (e.touches && e.touches[0].clientX);
    const clientY = e.clientY || (e.touches && e.touches[0].clientY);
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return { x: (clientX - rect.left) * scaleX, y: (clientY - rect.top) * scaleY };
  };

  const clearSign = () => {
    const canvas = signCanvasRef.current;
    if (canvas) canvas.getContext('2d')?.clearRect(0, 0, canvas.width, canvas.height);
    setCapturedSign(null);
  };

  const captureSign = () => {
    const canvas = signCanvasRef.current;
    if (!canvas) return;
    setCapturedSign(canvas.toDataURL('image/png'));
  };

  const handleSignDrag = (e: any) => {
    if (!isDraggingSign || !signWorkspaceRef.current) return;
    const rect = signWorkspaceRef.current.getBoundingClientRect();
    const clientX = e.clientX || (e.touches && e.touches[0].clientX);
    const clientY = e.clientY || (e.touches && e.touches[0].clientY);
    const x = ((clientX - rect.left) / rect.width) * 100;
    const y = ((clientY - rect.top) / rect.height) * 100;
    setSignPos({ x, y });
  };

  const handleMergePrint = () => {
    if(!signDoc || !capturedSign) return;
    const c = document.createElement('canvas'); const ctx = c.getContext('2d'); const d = new Image(); const s = new Image();
    d.onload = () => { 
      c.width = d.width; c.height = d.height; ctx?.drawImage(d,0,0); 
      s.onload = () => { 
        const sw = (d.width * 0.2) * signScale; const sh = (sw * 0.7); 
        const sx = (signPos.x / 100) * d.width - (sw / 2); 
        const sy = (signPos.y / 100) * d.height - (sh / 2); 
        ctx?.drawImage(s, sx, sy, sw, sh); 
        const link = document.createElement('a'); link.download = 'digital_signed.jpg'; 
        link.href = c.toDataURL('image/jpeg', 0.95); link.click(); 
      }; 
      s.src = capturedSign; 
    }; 
    d.src = signDoc;
  };

  return (
    <div className="space-y-8 animate-in fade-in">
      <div className="flex bg-white p-1 rounded-2xl border shadow-sm w-fit mx-auto md:mx-0">
        <button onClick={() => setActiveTool('photo')} className={`px-8 py-3 rounded-xl text-sm font-black transition-all flex items-center gap-2 ${activeTool === 'photo' ? 'bg-amber-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>
          <Scissors size={18} /> Photo Lab
        </button>
        <button onClick={() => setActiveTool('esign')} className={`px-8 py-3 rounded-xl text-sm font-black transition-all flex items-center gap-2 ${activeTool === 'esign' ? 'bg-amber-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>
          <PenTool size={18} /> Digital Sign
        </button>
        <button onClick={() => setActiveTool('pdf')} className={`px-8 py-3 rounded-xl text-sm font-black transition-all flex items-center gap-2 ${activeTool === 'pdf' ? 'bg-amber-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>
          <FileType size={18} /> PDF Tools
        </button>
      </div>

      {activeTool === 'photo' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-[3rem] border shadow-xl space-y-6 h-fit">
            <h3 className="text-xl font-black flex items-center gap-2"><Camera className="text-amber-600" /> Image Studio</h3>
            <div className="space-y-4">
              <label className="block p-8 border-2 border-dashed rounded-3xl text-center cursor-pointer hover:bg-amber-50 transition-colors">
                <input type="file" className="hidden" accept="image/*" onChange={handlePhotoUpload} />
                <Upload className="mx-auto mb-2 text-slate-300" />
                <p className="text-xs font-bold text-slate-500">{photoFile ? 'Change Image' : 'Click to Upload'}</p>
              </label>

              {photoFile && !isCropping && (
                <>
                  <button onClick={() => setIsCropping(true)} className="w-full py-3 bg-slate-100 text-slate-600 rounded-xl font-bold text-xs flex items-center justify-center gap-2 mb-2"><Crop size={14}/> Adjust Crop</button>
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => setPhotoBg('white')} className={`py-3 border rounded-xl font-bold text-xs ${photoBg === 'white' ? 'bg-amber-600 text-white border-amber-600' : 'bg-slate-50 text-slate-600'}`}>White BG</button>
                    <button onClick={() => setPhotoBg('blue')} className={`py-3 border rounded-xl font-bold text-xs ${photoBg === 'blue' ? 'bg-amber-600 text-white border-amber-600' : 'bg-slate-50 text-slate-600'}`}>Blue BG</button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => setPhotoCount(4)} className={`py-3 border rounded-xl font-bold text-xs ${photoCount === 4 ? 'bg-amber-600 text-white border-amber-600' : 'bg-slate-50 text-slate-600'}`}>4 Photos</button>
                    <button onClick={() => setPhotoCount(8)} className={`py-3 border rounded-xl font-bold text-xs ${photoCount === 8 ? 'bg-amber-600 text-white border-amber-600' : 'bg-slate-50 text-slate-600'}`}>8 Photos</button>
                  </div>
                  <button onClick={() => { if(photoCanvasRef.current) { const link = document.createElement('a'); link.download = 'passport_sheet.jpg'; link.href = photoCanvasRef.current.toDataURL('image/jpeg'); link.click(); } }} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black shadow-xl flex items-center justify-center gap-2">
                    <Printer size={20} /> Print Passport Sheet
                  </button>
                </>
              )}

              {isCropping && (
                <div className="space-y-4 pt-2">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex justify-between"><span>Area Size</span><span>{Math.round(cropArea.width)}%</span></label>
                    <input type="range" min="10" max="90" step="1" value={cropArea.width} onChange={e => { const v = parseFloat(e.target.value); setCropArea(prev => ({ ...prev, width: v, height: v })); }} className="w-full accent-amber-600" />
                  </div>
                  <button onClick={() => setIsCropping(false)} className="w-full bg-amber-600 text-white py-4 rounded-xl font-black shadow-lg flex items-center justify-center gap-2"><Check size={20} /> Apply Selection</button>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-2 bg-white rounded-[3rem] border shadow-xl p-8 flex flex-col items-center justify-center min-h-[600px] bg-slate-100/30">
             {photoFile ? (
               isCropping ? (
                 <div ref={cropWorkspaceRef} className="relative bg-black rounded-3xl overflow-hidden shadow-2xl max-w-full cursor-move" onMouseMove={handleCropDrag} onMouseUp={() => setIsDraggingCrop(false)} onTouchMove={handleCropDrag} onTouchEnd={() => setIsDraggingCrop(false)}>
                   <img src={photoFile} alt="Crop" className="max-w-full h-auto opacity-50" />
                   <div className="absolute border-2 border-amber-500 shadow-[0_0_0_1000px_rgba(0,0,0,0.5)]" style={{ left: `${cropArea.x}%`, top: `${cropArea.y}%`, width: `${cropArea.width}%`, height: `${cropArea.height}%` }} />
                   <div className="absolute inset-0" onMouseDown={() => setIsDraggingCrop(true)} onTouchStart={() => setIsDraggingCrop(true)} />
                 </div>
               ) : (
                 <div className="scale-75 origin-center"><canvas ref={photoCanvasRef} className="shadow-2xl border-4 border-white max-w-full" /></div>
               )
             ) : (
               <div className="text-center opacity-30"><ImageIcon size={64} className="mx-auto mb-4" /><p className="font-black text-lg">Upload an image to start</p></div>
             )}
          </div>
        </div>
      )}

      {activeTool === 'esign' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
           <div className="lg:col-span-1 bg-white p-8 rounded-[3rem] border shadow-xl space-y-6">
              <h3 className="text-xl font-black flex items-center gap-2"><PenTool className="text-amber-600" /> Digital Signer</h3>
              <div className="space-y-4">
                <div className="p-4 bg-slate-50 rounded-2xl border">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">1. Draw on Pad</label>
                  <canvas ref={signCanvasRef} width={400} height={200} className="w-full h-32 bg-white rounded-xl border cursor-crosshair mb-3" onMouseDown={startDrawing} onMouseMove={draw} onMouseUp={() => { setIsDrawing(false); captureSign(); }} onTouchStart={startDrawing} onTouchMove={draw} onTouchEnd={() => { setIsDrawing(false); captureSign(); }} />
                  <button onClick={clearSign} className="w-full py-2 text-xs font-bold text-slate-400 hover:text-rose-500 flex items-center justify-center gap-1"><RefreshCw size={12}/> Reset</button>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">2. Select Document</label>
                  <label className="w-full flex items-center justify-center gap-2 p-4 bg-white border rounded-2xl cursor-pointer hover:bg-slate-50 transition-colors">
                    <input type="file" className="hidden" accept="image/*" onChange={(e) => { const f = e.target.files?.[0]; if(f) { const r = new FileReader(); r.onload = () => setSignDoc(r.result as string); r.readAsDataURL(f); } }} />
                    <Upload size={18} className="text-slate-400" /><span className="text-xs font-bold text-slate-600">Choose Image</span>
                  </label>
                </div>
                {capturedSign && signDoc && (
                  <div className="space-y-4 pt-4 border-t">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 flex justify-between uppercase tracking-widest"><span>Sign Size</span><span>{Math.round(signScale * 100)}%</span></label>
                      <input type="range" min="0.5" max="3" step="0.1" value={signScale} onChange={e => setSignScale(parseFloat(e.target.value))} className="w-full accent-amber-600" />
                    </div>
                    <button onClick={handleMergePrint} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black shadow-xl flex items-center justify-center gap-2 hover:bg-black transition-all">
                      <Download size={20} /> Merge & Download
                    </button>
                  </div>
                )}
              </div>
           </div>

           <div className="lg:col-span-3 bg-white rounded-[3rem] border shadow-xl p-8 min-h-[600px] flex flex-col relative overflow-hidden bg-slate-100/30">
              <div ref={signWorkspaceRef} className="flex-grow rounded-3xl relative overflow-hidden flex items-center justify-center cursor-move" onMouseMove={handleSignDrag} onMouseUp={() => setIsDraggingSign(false)} onTouchMove={handleSignDrag} onTouchEnd={() => setIsDraggingSign(false)}>
                {signDoc ? (
                  <div className="relative max-w-full max-h-full">
                    <img src={signDoc} alt="Document" className="max-w-full max-h-full object-contain pointer-events-none" />
                    {capturedSign && (
                      <div className="absolute pointer-events-none" style={{ left: `${signPos.x}%`, top: `${signPos.y}%`, transform: `translate(-50%, -50%) scale(${signScale})` }}>
                        <img src={capturedSign} alt="Sign" className="w-32 h-auto" />
                      </div>
                    )}
                    <div className="absolute inset-0" onMouseDown={() => setIsDraggingSign(true)} onTouchStart={() => setIsDraggingSign(true)} />
                  </div>
                ) : (
                  <p className="text-slate-300 font-black bengali-font">একটি ডকুমেন্ট ছবি আপলোড করুন</p>
                )}
              </div>
              <div className="mt-4 flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <span><Move size={12} className="inline mr-1"/> Drag signature to position</span>
                <span><Maximize2 size={12} className="inline mr-1"/> Resize with slider</span>
              </div>
           </div>
        </div>
      )}

      {activeTool === 'pdf' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-[3rem] border shadow-xl space-y-6 h-fit">
            <h3 className="text-xl font-black flex items-center gap-2"><FileType className="text-amber-600" /> Digital Files</h3>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex justify-between"><span>Compression</span><span>{Math.round(compressLevel * 100)}%</span></label>
                <input type="range" min="0.1" max="1.0" step="0.1" className="w-full accent-amber-600" value={compressLevel} onChange={(e) => setCompressLevel(parseFloat(e.target.value))} />
              </div>
              <label className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2 shadow-xl hover:bg-black cursor-pointer">
                <Plus size={20} /> Select Images
                <input type="file" className="hidden" multiple accept="image/*" onChange={(e) => { const f = e.target.files; if(f) Array.from(f).forEach((file: File) => { const r = new FileReader(); r.onload = () => setPdfImages(p => [...p, r.result as string]); r.readAsDataURL(file); }); }} />
              </label>
              <button onClick={() => setPdfImages([])} className="w-full bg-slate-100 text-rose-500 py-4 rounded-2xl font-black flex items-center justify-center gap-2"><Trash2 size={18} /> Clear Gallery</button>
            </div>
          </div>
          <div className="lg:col-span-2 bg-white rounded-[3rem] border shadow-xl p-8 min-h-[400px]">
             <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
               {pdfImages.map((img, idx) => (
                 <div key={idx} className="aspect-square rounded-2xl overflow-hidden border relative group">
                   <img src={img} className="w-full h-full object-cover" alt="PDF" />
                   <button onClick={() => setPdfImages(p => p.filter((_, i) => i !== idx))} className="absolute top-2 right-2 p-1 bg-rose-500 text-white rounded-lg opacity-0 group-hover:opacity-100"><Trash2 size={12}/></button>
                 </div>
               ))}
               {pdfImages.length === 0 && <p className="col-span-full text-center text-slate-300 font-bold py-20">No images selected for merge.</p>}
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ShopUtilities;
