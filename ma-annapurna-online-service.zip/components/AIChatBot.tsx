
import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, X, Bot, User, Loader2, Sparkles, UserCircle, Heart, Globe, AlertCircle } from 'lucide-react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { BUSINESS_INFO } from '../constants';

const AIChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string; links?: { uri: string; title: string }[] }[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const chatInstance = useRef<any>(null);
  const [adminTip, setAdminTip] = useState(() => localStorage.getItem('ma_bot_tip') || '');

  // Listen for storage changes to sync bot tip across tabs/views
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'ma_bot_tip') {
        const newTip = e.newValue || '';
        setAdminTip(newTip);
        // Reset chat instance to force re-initialization with new instruction
        chatInstance.current = null;
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  // Initialize Chat Session whenever adminTip changes or is reset
  useEffect(() => {
    if (!chatInstance.current) {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      chatInstance.current = ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
          systemInstruction: `আপনার নাম "লিনা" (Lina)। আপনি "মা অন্নপূর্ণা অনলাইন সার্ভিস" এর AI অ্যাসিস্ট্যান্ট। 
          দোকানের অবস্থান: রাজহাটী সিনেমাতলা মোড়। পরিচালক: ভবাণী ব্যানার্জী।
          
          অ্যাডমিন থেকে বিশেষ বার্তা (যদি থাকে): "${adminTip}"
          
          নিয়মাবলী:
          ১. অ্যাডমিন টিপসটি যদি গ্রাহকের প্রশ্নের সাথে প্রাসঙ্গিক হয়, তবে তা উল্লেখ করুন।
          ২. সবসময় বাংলায় প্রফেশনাল এবং নম্রভাবে কথা বলুন।
          ৩. গ্রাহককে দোকানে আসার উৎসাহ দিন (ফোন: 8145685318)।
          ৪. অজানা তথ্যের জন্য Google Search ব্যবহার করুন।`,
          tools: [{ googleSearch: {} }],
        },
      });

      // Reset messages if it's a fresh initialization due to tip change
      if (messages.length > 0) {
          setMessages(prev => [
            ...prev,
            { role: 'model', text: `[সিস্টেম আপডেট]: অ্যাডমিন আমার নির্দেশাবলী পরিবর্তন করেছেন। এখন থেকে আমি নতুন তথ্যের ভিত্তিতে আপনাকে সাহায্য করব।${adminTip ? '\n\nনতুন আপডেট: ' + adminTip : ''}` }
          ]);
      } else {
          setMessages([
            { role: 'model', text: `নমস্কার! আমি লিনা। মা অন্নপূর্ণা অনলাইন সার্ভিসে আপনাকে স্বাগত। ${adminTip ? '\n\nআজকের বিশেষ আপডেট: ' + adminTip : 'আমি আপনাকে কীভাবে সাহায্য করতে পারি?'}` }
          ]);
      }
    }
  }, [adminTip]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const result = await chatInstance.current.sendMessageStream({ message: userMessage });
      let modelText = '';
      setMessages(prev => [...prev, { role: 'model', text: '' }]);

      for await (const chunk of result) {
        const c = chunk as GenerateContentResponse;
        modelText += c.text;
        setMessages(prev => {
          const last = prev[prev.length - 1];
          return [...prev.slice(0, -1), { ...last, text: modelText }];
        });
      }
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: 'দুঃখিত, সংযোগ বিচ্ছিন হয়েছে। আবার চেষ্টা করুন।' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100] flex flex-col items-end">
      {isOpen && (
        <div className="mb-4 w-[90vw] sm:w-[400px] h-[550px] bg-white rounded-[2.5rem] shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-in slide-in-from-bottom-4 duration-300">
          <div className="bg-slate-900 p-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center rotate-3">
                <UserCircle size={32} className="text-slate-900" />
              </div>
              <div>
                <h4 className="font-black text-lg bengali-font">লিনা AI</h4>
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Online Help Desk</span>
                </div>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-white/10 rounded-full text-slate-400"><X size={24} /></button>
          </div>

          <div ref={scrollRef} className="flex-grow p-6 overflow-y-auto space-y-4 bg-slate-50/50 custom-scrollbar">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in`}>
                <div className={`p-4 rounded-2xl text-sm bengali-font max-w-[85%] shadow-sm ${msg.role === 'user' ? 'bg-slate-900 text-white' : 'bg-white text-slate-700 border'}`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start animate-in fade-in">
                <div className="p-4 rounded-2xl bg-white border shadow-sm">
                   <Loader2 size={18} className="animate-spin text-amber-500" />
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSendMessage} className="p-4 bg-white border-t flex items-center gap-2">
            <input type="text" placeholder="প্রশ্ন করুন..." className="flex-grow p-4 bg-slate-50 border rounded-2xl outline-none text-sm bengali-font" value={input} onChange={e => setInput(e.target.value)} />
            <button type="submit" disabled={isLoading} className="p-4 bg-amber-500 text-slate-900 rounded-2xl shadow-lg hover:bg-amber-600 transition-all disabled:opacity-50"><Send size={24} /></button>
          </form>
        </div>
      )}

      <button onClick={() => setIsOpen(!isOpen)} className={`w-16 h-16 rounded-[1.5rem] shadow-2xl flex items-center justify-center transition-all duration-500 bg-slate-900 hover:scale-110 relative`}>
        {isOpen ? <X size={32} className="text-white" /> : <MessageSquare size={32} className="text-amber-500" />}
        {!isOpen && adminTip && <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 rounded-full border-2 border-white animate-pulse"></span>}
      </button>
    </div>
  );
};

export default AIChatBot;
