
import React, { useState, useEffect, useRef } from 'react';
import { Table as TableIcon, FileText, Plus, Save, Trash2, Download, Printer, CheckCircle, Settings, Eye, Clock, Rocket, Globe, Info, Search, ShieldCheck, AlertCircle, RefreshCw, Send, Check, Smartphone, Users } from 'lucide-react';
import { OfficeDoc, ShopHeader, DocStatus, AppNotification, User } from '../types';

interface OfficeToolsProps {
  lang?: 'bn' | 'en';
}

const OfficeTools: React.FC<OfficeToolsProps> = ({ lang = 'bn' }) => {
  const [activeTool, setActiveTool] = useState<'excel' | 'word'>('excel');
  const [customerPhone, setCustomerPhone] = useState('');
  const [verifiedUsers, setVerifiedUsers] = useState<User[]>([]);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  
  const [shopHeader, setShopHeader] = useState<ShopHeader>(() => {
    const saved = localStorage.getItem('ma_shop_header');
    return saved ? JSON.parse(saved) : {
      name: "মা অন্নপূর্ণা অনলাইন সার্ভিস",
      address: "রাজহাটী, গুইরাম হাজরা ভ্যারাইটি স্টোর, ২য় তল।",
      phone: "8145685318 / 9734420340",
      showLogo: true
    };
  });

  const [docs, setDocs] = useState<OfficeDoc[]>(() => {
    const saved = localStorage.getItem('ma_office_docs');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [currentTitle, setCurrentTitle] = useState('নতুন ডকুমেন্ট');
  const [currentStatus, setCurrentStatus] = useState<DocStatus>('draft');
  const [excelContent, setExcelContent] = useState<string[][]>(Array(10).fill(0).map(() => Array(6).fill('')));
  const [wordContent, setWordContent] = useState('');
  const [saveStatus, setSaveStatus] = useState(false);

  useEffect(() => {
    localStorage.setItem('ma_office_docs', JSON.stringify(docs));
    const savedUsers = JSON.parse(localStorage.getItem('ma_users') || '[]');
    setVerifiedUsers(savedUsers);
  }, [docs]);

  const handleSave = (status: DocStatus = 'draft') => {
    const docData: OfficeDoc = {
      id: currentId || Date.now().toString(),
      title: currentTitle,
      type: activeTool,
      lastModified: new Date().toLocaleString('bn-BD'),
      content: activeTool === 'excel' ? excelContent : wordContent,
      header: shopHeader,
      targetPhone: customerPhone.trim(),
      status: status
    };

    if (currentId) {
      setDocs(docs.map(d => d.id === currentId ? docData : d));
    } else {
      setDocs([docData, ...docs]);
      setCurrentId(docData.id);
    }

    // Send notification if a user is linked
    if (customerPhone.trim()) {
      const notifications: AppNotification[] = JSON.parse(localStorage.getItem('ma_notifications') || '[]');
      let msg = '';
      let title = '';
      
      if (status === 'recheck') {
        title = 'ডকুমেন্ট রিচেক প্রয়োজন';
        msg = `আপনার "${currentTitle}" ডকুমেন্টটি অ্যাডমিন দ্বারা রিচেক করার জন্য পাঠানো হয়েছে।`;
      } else if (status === 'verified') {
        title = 'ডকুমেন্ট সম্পন্ন হয়েছে';
        msg = `আপনার "${currentTitle}" ডকুমেন্টটি এখন ভেরিফাইড এবং ব্যবহারের জন্য প্রস্তুত।`;
      }

      if (title) {
        const newNotif: AppNotification = {
          id: Date.now().toString(),
          title,
          message: msg,
          type: 'work',
          timestamp: new Date().toLocaleString('bn-BD'),
          targetPhone: customerPhone.trim(),
          isRead: false
        };
        const updatedNotifs = [newNotif, ...notifications];
        localStorage.setItem('ma_notifications', JSON.stringify(updatedNotifs));
        window.dispatchEvent(new StorageEvent('storage', { key: 'ma_notifications', newValue: JSON.stringify(updatedNotifs) }));
      }
    }

    setCurrentStatus(status);
    setSaveStatus(true);
    setTimeout(() => setSaveStatus(false), 2000);
  };

  const loadDoc = (doc: OfficeDoc) => {
    setActiveTool(doc.type);
    setCurrentId(doc.id);
    setCurrentTitle(doc.title);
    setCurrentStatus(doc.status);
    setCustomerPhone(doc.targetPhone || '');
    if (doc.type === 'excel') setExcelContent(doc.content);
    else setWordContent(doc.content);
  };

  const createNew = () => {
    setCurrentId(null);
    setCurrentTitle(lang === 'bn' ? `নতুন ফাইল ${docs.length + 1}` : `New File ${docs.length + 1}`);
    setCurrentStatus('draft');
    setExcelContent(Array(10).fill(0).map(() => Array(6).fill('')));
    setWordContent('');
    setCustomerPhone('');
  };

  const downloadDoc = () => {
    let content = `${shopHeader.name}\n${shopHeader.address}\n${shopHeader.phone}\n\n${currentTitle}\n\n`;
    let fileName = `${currentTitle}.txt`;
    
    if (activeTool === 'excel') {
      content += excelContent.map(row => row.join(',')).join('\n');
      fileName = `${currentTitle}.csv`;
    } else {
      content += wordContent;
    }
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`space-y-6 animate-in fade-in ${lang === 'bn' ? 'bengali-font' : ''}`}>
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #printable-area, #printable-area * { visibility: visible; }
          #printable-area { position: absolute; left: 0; top: 0; width: 100%; padding: 30px; }
          .no-print { display: none !important; }
        }
      `}</style>

      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6 no-print">
        <div className="flex bg-white p-1 rounded-2xl border shadow-sm">
          <button onClick={() => { setActiveTool('excel'); createNew(); }} className={`px-6 py-3 rounded-xl flex items-center gap-2 text-sm font-bold transition-all ${activeTool === 'excel' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}><TableIcon size={18} /> Excel</button>
          <button onClick={() => { setActiveTool('word'); createNew(); }} className={`px-6 py-3 rounded-xl flex items-center gap-2 text-sm font-bold transition-all ${activeTool === 'word' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}><FileText size={18} /> Word</button>
        </div>
        <div className="flex gap-2">
          <button onClick={() => window.print()} className="bg-white border p-3 rounded-xl hover:bg-slate-50 shadow-sm"><Printer size={20} /></button>
          <button onClick={createNew} className="bg-slate-900 text-white px-6 py-3 rounded-xl flex items-center gap-2 font-bold hover:bg-black shadow-lg"><Plus size={18} /> নতুন ফাইল</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-4 no-print">
          <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-xl h-fit">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2"><Clock size={12}/> Project History</h4>
            <div className="space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar">
              {docs.length === 0 && <div className="py-10 text-center opacity-30 text-xs font-bold">No saved documents.</div>}
              {docs.map(doc => (
                <div key={doc.id} onClick={() => loadDoc(doc)} className={`p-4 rounded-2xl cursor-pointer border transition-all ${currentId === doc.id ? 'bg-amber-50 border-amber-200 ring-2 ring-amber-50' : 'bg-slate-50 border-transparent hover:bg-slate-100'}`}>
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-black text-slate-800 truncate">{doc.title}</p>
                    <div className={`w-2 h-2 rounded-full ${doc.status === 'verified' ? 'bg-emerald-500' : doc.status === 'recheck' ? 'bg-amber-500' : 'bg-slate-300'}`}></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] text-slate-400 font-bold">{doc.lastModified.split(',')[0]}</p>
                    <span className="text-[8px] font-black uppercase text-slate-400">{doc.type}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-3">
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-2xl flex flex-col min-h-[800px]">
            <div className="bg-slate-50 px-10 py-6 border-b flex flex-wrap items-center justify-between gap-6 no-print">
              <div className="flex-grow max-w-xl space-y-2">
                <input type="text" value={currentTitle} onChange={(e) => setCurrentTitle(e.target.value)} className="bg-transparent font-black text-2xl text-slate-800 outline-none w-full" placeholder="Project Name..." />
                
                {/* Searchable User Dropdown */}
                <div className="relative">
                  <div 
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                    className="flex items-center gap-2 px-3 py-1.5 bg-white border rounded-lg text-[10px] font-bold text-slate-600 uppercase tracking-widest cursor-pointer hover:bg-slate-50 transition-colors w-fit"
                  >
                    <Users size={12} className="text-amber-500" />
                    {customerPhone ? `Linked: ${verifiedUsers.find(u => u.phone === customerPhone)?.name || customerPhone}` : 'Select Owner (Customer)'}
                  </div>
                  
                  {isUserMenuOpen && (
                    <div className="absolute top-full left-0 mt-2 w-64 bg-white border rounded-2xl shadow-2xl z-[60] overflow-hidden animate-in zoom-in-95">
                      <div className="p-2 border-b bg-slate-50">
                        <input 
                          type="tel" 
                          placeholder="Search phone..." 
                          className="w-full p-2 bg-white border rounded-xl outline-none text-[10px]"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                        />
                      </div>
                      <div className="max-h-48 overflow-y-auto custom-scrollbar">
                        {verifiedUsers.filter(u => u.phone.includes(customerPhone) || u.name.includes(customerPhone)).map(u => (
                          <div 
                            key={u.id} 
                            onClick={() => { setCustomerPhone(u.phone); setIsUserMenuOpen(false); }}
                            className="p-3 hover:bg-amber-50 cursor-pointer flex items-center justify-between group"
                          >
                            <div>
                              <p className="text-[10px] font-black text-slate-800">{u.name}</p>
                              <p className="text-[8px] text-slate-400 font-bold">{u.phone}</p>
                            </div>
                            <CheckCircle size={12} className={`opacity-0 group-hover:opacity-100 ${customerPhone === u.phone ? 'opacity-100 text-amber-500' : 'text-slate-200'}`} />
                          </div>
                        ))}
                      </div>
                      <div onClick={() => { setCustomerPhone(''); setIsUserMenuOpen(false); }} className="p-2 bg-slate-50 border-t text-center text-[8px] font-black text-rose-500 cursor-pointer hover:bg-rose-50 uppercase tracking-widest">Clear Assignment</div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <button onClick={downloadDoc} className="p-4 bg-white border rounded-2xl hover:bg-slate-100 shadow-sm transition-all"><Download size={20} /></button>
                <div className="flex bg-slate-200 p-1 rounded-2xl">
                   <button onClick={() => handleSave('draft')} className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${currentStatus === 'draft' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>Save Draft</button>
                   <button onClick={() => handleSave('recheck')} className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${currentStatus === 'recheck' ? 'bg-amber-500 text-white shadow-md' : 'text-slate-500 hover:text-amber-600'}`}><RefreshCw size={14}/> Recheck</button>
                   <button onClick={() => handleSave('verified')} className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${currentStatus === 'verified' ? 'bg-emerald-500 text-white shadow-md' : 'text-slate-500 hover:text-emerald-600'}`}><Check size={14}/> Verify</button>
                </div>
              </div>
            </div>

            <div id="printable-area" className="flex-grow p-12 bg-slate-100/50 overflow-auto">
              <div className="max-w-4xl mx-auto bg-white p-14 shadow-2xl min-h-[1000px] border border-slate-200 flex flex-col relative">
                {/* Letterhead */}
                <div className="text-center border-b-8 border-slate-900 pb-10 mb-10">
                  <h1 className="text-4xl font-black text-slate-900 mb-2 uppercase tracking-tighter">{shopHeader.name}</h1>
                  <p className="text-sm font-bold text-slate-500 bengali-font">{shopHeader.address}</p>
                  <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mt-2">Ph: {shopHeader.phone}</p>
                </div>
                
                <h2 className="text-2xl font-black text-center mb-12 uppercase tracking-widest underline underline-offset-8 decoration-4 decoration-amber-500">{currentTitle}</h2>
                
                {activeTool === 'excel' ? (
                  <div className="border-2 border-slate-900 rounded-lg overflow-hidden">
                    <table className="w-full border-collapse">
                      <tbody>
                        {excelContent.map((row, r) => (
                          <tr key={r}>
                            {row.map((cell, c) => (
                              <td key={c} className="border border-slate-300 p-3">
                                <input type="text" className="w-full bg-transparent outline-none font-bold text-slate-700 text-sm" value={cell} onChange={(e) => { const n = [...excelContent]; n[r][c] = e.target.value; setExcelContent(n); }} />
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <textarea className="flex-grow w-full outline-none resize-none text-xl leading-relaxed font-bold text-slate-700 bengali-font" value={wordContent} onChange={(e) => setWordContent(e.target.value)} placeholder="পর্চার তথ্য বা দলিলের খসড়া এখানে টাইপ করুন..." />
                )}
                
                <div className="mt-20 pt-10 border-t border-slate-100 flex justify-between items-end">
                  <div className="text-[10px] font-black text-slate-300 uppercase tracking-widest">
                    Digital Service by Ma Annapurna
                  </div>
                  <div className="text-center">
                    <div className="w-32 h-1 border-b border-slate-400 mb-2"></div>
                    <p className="text-[10px] font-black uppercase text-slate-400">Authorized Signature</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfficeTools;
