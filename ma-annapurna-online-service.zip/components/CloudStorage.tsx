
import React, { useState } from 'react';
import { User, CloudFile, AppNotification } from '../types';
import { Cloud, Upload, File as FileIcon, Image as ImageIcon, Trash2, HardDrive, ShieldCheck, CheckCircle, Loader2, Activity, Download, LayoutGrid, List, Send, Share2 } from 'lucide-react';

interface CloudStorageProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
}

const CloudStorage: React.FC<CloudStorageProps> = ({ user, onUpdateUser }) => {
  const [isUploading, setIsUploading] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sharingId, setSharingId] = useState<string | null>(null);
  
  const STORAGE_LIMIT = 10 * 1024 * 1024 * 1024; // 10 GB
  const usagePercentage = (user.storageUsed / STORAGE_LIMIT) * 100;

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const totalNewSize = Array.from(files).reduce((acc, f: any) => acc + f.size, 0);
      
      if (user.storageUsed + totalNewSize > STORAGE_LIMIT) {
        alert("আপনার ১০জিবি স্টোরেজ পূর্ণ হয়ে গেছে। কিছু ফাইল ডিলিট করুন।");
        return;
      }

      setIsUploading(true);
      setTimeout(() => {
        const newFiles: CloudFile[] = Array.from(files).map((f: any) => ({
          id: Math.random().toString(36).substr(2, 9),
          name: f.name,
          type: f.type,
          size: f.size,
          uploadDate: new Date().toLocaleDateString('bn-BD'),
          category: f.type.startsWith('image/') ? 'image' : 'document'
        }));
        
        onUpdateUser({ ...user, storageUsed: user.storageUsed + totalNewSize, files: [...newFiles, ...user.files] });
        setIsUploading(false);
      }, 1500);
    }
  };

  const deleteFile = (file: CloudFile) => {
    if (window.confirm('আপনি কি এই ফাইলটি ডিলিট করতে চান?')) {
      onUpdateUser({ ...user, storageUsed: user.storageUsed - file.size, files: user.files.filter(f => f.id !== file.id) });
    }
  };

  const shareWithShop = (file: CloudFile) => {
    setSharingId(file.id);
    
    // Simulate sharing by adding to a global 'ma_user_shared' list for Admin
    const sharedFiles = JSON.parse(localStorage.getItem('ma_user_shared_inbox') || '[]');
    const newEntry = {
      ...file,
      ownerName: user.name,
      ownerPhone: user.phone,
      sharedAt: new Date().toLocaleString('bn-BD')
    };
    
    localStorage.setItem('ma_user_shared_inbox', JSON.stringify([newEntry, ...sharedFiles]));
    
    // Trigger storage event for real-time admin notification
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'ma_user_shared_inbox',
      newValue: JSON.stringify([newEntry, ...sharedFiles])
    }));

    setTimeout(() => {
      setSharingId(null);
      alert('ফাইলটি অ্যাডমিনের কাছে পাঠানো হয়েছে। ধন্যবাদ!');
    }, 1000);
  };

  return (
    <div className="space-y-8 animate-in fade-in">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-[2.5rem] border shadow-xl flex items-center space-x-6">
          <div className="bg-amber-50 p-4 rounded-2xl text-amber-600"><HardDrive size={32} /></div>
          <div><h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Storage Used</h4><p className="text-2xl font-black">{formatSize(user.storageUsed)}</p></div>
        </div>
        <div className="bg-white p-8 rounded-[2.5rem] border shadow-xl flex items-center space-x-6">
          <div className="bg-blue-50 p-4 rounded-2xl text-blue-600"><Cloud size={32} /></div>
          <div><h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Limit</h4><p className="text-2xl font-black">10.0 GB</p></div>
        </div>
        <div className="bg-white p-8 rounded-[2.5rem] border shadow-xl flex items-center space-x-6">
          <div className="bg-emerald-50 p-4 rounded-2xl text-emerald-600"><ShieldCheck size={32} /></div>
          <div><h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Security</h4><p className="text-2xl font-black">Encrypted</p></div>
        </div>
      </div>

      <div className="bg-white p-10 rounded-[3rem] border shadow-xl">
        <div className="flex items-center justify-between mb-4">
           <h3 className="font-black text-xl text-slate-800 flex items-center gap-2 bengali-font"><Activity size={24} className="text-amber-500" /> স্টোরেজ মিটার</h3>
           <span className="text-sm font-black text-amber-600">{usagePercentage.toFixed(2)}% full</span>
        </div>
        <div className="w-full bg-slate-100 h-6 rounded-full overflow-hidden border p-1 shadow-inner">
           <div className={`h-full rounded-full transition-all duration-1000 ${usagePercentage > 90 ? 'bg-rose-500' : 'bg-amber-500'}`} style={{ width: `${Math.max(usagePercentage, 2)}%` }} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white p-8 rounded-[2.5rem] border-2 border-dashed border-slate-200 hover:border-amber-400 transition-all group relative overflow-hidden text-center">
             <input type="file" multiple className="absolute inset-0 opacity-0 cursor-pointer z-10" onChange={handleFileUpload} disabled={isUploading} />
             <div className="py-6">
                <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center text-amber-600 mx-auto mb-4 group-hover:scale-110 transition-transform"><Upload size={32} /></div>
                <h4 className="font-black text-lg text-slate-800 bengali-font">ফাইল আপলোড</h4>
                <p className="text-xs text-slate-400 mt-2">ফ্রি ১০জিবি ক্লাউড ব্যাকআপ</p>
             </div>
          </div>
          {isUploading && <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl flex items-center gap-3 font-bold text-amber-600 animate-pulse text-sm"><Loader2 className="animate-spin" size={18} /> আপলোড হচ্ছে...</div>}
        </div>

        <div className="lg:col-span-3">
          <div className="bg-white rounded-[3rem] border shadow-xl overflow-hidden min-h-[500px]">
            <div className="p-8 border-b flex items-center justify-between bg-slate-50/50">
               <h3 className="font-black text-xl text-slate-800 flex items-center gap-3 bengali-font"><Cloud className="text-amber-500" /> আমার ফাইলসমূহ</h3>
               <div className="flex bg-white border rounded-xl p-1">
                  <button onClick={() => setViewMode('grid')} className={`p-2 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400'}`}><LayoutGrid size={18}/></button>
                  <button onClick={() => setViewMode('list')} className={`p-2 rounded-lg transition-all ${viewMode === 'list' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400'}`}><List size={18}/></button>
               </div>
            </div>

            <div className="p-8 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
               {user.files.map((file) => (
                 <div key={file.id} className="bg-slate-50 border rounded-3xl p-6 text-center group relative hover:border-amber-400 transition-all">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4 ${file.category === 'image' ? 'bg-blue-100 text-blue-600' : 'bg-amber-100 text-amber-600'}`}>
                       {file.category === 'image' ? <ImageIcon size={28} /> : <FileIcon size={28} />}
                    </div>
                    <p className="text-xs font-bold text-slate-700 truncate mb-1">{file.name}</p>
                    <p className="text-[10px] font-black text-slate-400 uppercase">{formatSize(file.size)}</p>
                    
                    <div className="mt-4 flex flex-col gap-2">
                       <button 
                         onClick={() => shareWithShop(file)} 
                         disabled={sharingId === file.id}
                         className={`w-full py-2 rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-2 transition-all ${sharingId === file.id ? 'bg-emerald-500 text-white' : 'bg-slate-900 text-white hover:bg-black'}`}
                       >
                         {sharingId === file.id ? <CheckCircle size={12}/> : <Share2 size={12}/>}
                         {sharingId === file.id ? 'Shared' : 'Share with Shop'}
                       </button>
                    </div>

                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                       <button onClick={() => deleteFile(file)} className="p-1.5 bg-rose-50 text-rose-500 rounded-lg"><Trash2 size={14} /></button>
                    </div>
                 </div>
               ))}
               {user.files.length === 0 && (
                 <div className="col-span-full py-20 text-center opacity-30 select-none">
                    <Cloud size={64} className="mx-auto mb-4" />
                    <p className="font-black text-xl bengali-font">কোনো ফাইল আপলোড করা নেই</p>
                 </div>
               )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CloudStorage;
