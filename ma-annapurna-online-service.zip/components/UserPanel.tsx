
import React, { useState, useEffect } from 'react';
import { Search, Cloud, FileText, Rocket, Zap, Bell, CheckCircle, ListTodo, Smartphone, Heart, Sparkles, UserPlus, Phone, Lock, ShieldCheck, Printer, Download, RefreshCw, Eye, X } from 'lucide-react';
import { User, AppNotification, ToDo, ManualApplication, OfficeDoc } from '../types';
import CloudStorage from './CloudStorage.tsx';

interface UserPanelProps {
  currentUser: User | null;
  onUpdateUser: (updatedUser: User) => void;
  onOpenAuth?: () => void;
  lang?: 'bn' | 'en';
}

const UserPanel: React.FC<UserPanelProps> = ({ currentUser, onUpdateUser, onOpenAuth, lang = 'bn' }) => {
  const [activeView, setActiveView] = useState<'home' | 'records' | 'notifications' | 'storage'>('home');
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [userTasks, setUserTasks] = useState<ToDo[]>([]);
  const [applications, setApplications] = useState<ManualApplication[]>([]);
  const [officeDocs, setOfficeDocs] = useState<OfficeDoc[]>([]);
  
  const [previewDoc, setPreviewDoc] = useState<OfficeDoc | ManualApplication | null>(null);

  const loadUserData = () => {
    if (currentUser) {
      const allNotifs: AppNotification[] = JSON.parse(localStorage.getItem('ma_notifications') || '[]');
      setNotifications(allNotifs.filter(n => n.targetPhone === currentUser.phone));

      const allTodos: ToDo[] = JSON.parse(localStorage.getItem('ma_todos') || '[]');
      setUserTasks(allTodos.filter(t => t.targetPhone === currentUser.phone));

      const allApps: ManualApplication[] = JSON.parse(localStorage.getItem('ma_all_applications') || '[]');
      setApplications(allApps.filter(a => a.phone === currentUser.phone));

      const allDocs: OfficeDoc[] = JSON.parse(localStorage.getItem('ma_office_docs') || '[]');
      setOfficeDocs(allDocs.filter(d => d.targetPhone === currentUser.phone));
    }
  };

  useEffect(() => {
    loadUserData();
    
    const handleStorage = (e: StorageEvent) => {
      if (['ma_notifications', 'ma_todos', 'ma_all_applications', 'ma_office_docs'].includes(e.key || '')) {
        loadUserData();
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [currentUser, activeView]);

  const requestRecheck = (id: string, type: 'app' | 'doc') => {
    if (window.confirm('আপনি কি এই তথ্যে কোনো ভুল খুঁজে পেয়েছেন? অ্যাডমিনকে রিচেক করার অনুরোধ পাঠাতে চান?')) {
      if (type === 'app') {
        const allApps: ManualApplication[] = JSON.parse(localStorage.getItem('ma_all_applications') || '[]');
        const updated = allApps.map(a => a.id === id ? { ...a, status: 'Pending' as any } : a);
        localStorage.setItem('ma_all_applications', JSON.stringify(updated));
        window.dispatchEvent(new StorageEvent('storage', { key: 'ma_all_applications', newValue: JSON.stringify(updated) }));
      } else {
        const allDocs: OfficeDoc[] = JSON.parse(localStorage.getItem('ma_office_docs') || '[]');
        const updated = allDocs.map(d => d.id === id ? { ...d, status: 'recheck' as any } : d);
        localStorage.setItem('ma_office_docs', JSON.stringify(updated));
        window.dispatchEvent(new StorageEvent('storage', { key: 'ma_office_docs', newValue: JSON.stringify(updated) }));
      }
      alert('অ্যাডমিনকে জানানো হয়েছে। অনুগ্রহ করে অপেক্ষা করুন।');
      loadUserData();
    }
  };

  if (!currentUser) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center animate-in fade-in">
        <div className="bg-white p-16 rounded-[3.5rem] border-2 border-dashed border-slate-200">
           <div className="w-20 h-20 bg-amber-50 rounded-3xl flex items-center justify-center mx-auto mb-6 text-amber-500 shadow-sm"><Lock size={40} /></div>
           <h2 className="text-3xl font-black mb-4 bengali-font">ব্যক্তিগত পোর্টাল অ্যাক্সেস</h2>
           <p className="text-slate-400 mb-8 bengali-font">আপনার করা আবেদনের স্ট্যাটাস এবং পার্সোনাল এলার্ট দেখতে লগইন করুন।</p>
           <button onClick={onOpenAuth} className="bg-slate-900 text-white px-10 py-5 rounded-2xl font-black text-lg flex items-center gap-3 mx-auto shadow-2xl hover:scale-105 transition-all">
              <UserPlus size={24} /> শুরু করুন
           </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`animate-in fade-in duration-700 pb-20 ${lang === 'bn' ? 'bengali-font' : ''}`}>
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #printable-record, #printable-record * { visibility: visible; }
          #printable-record { position: absolute; left: 0; top: 0; width: 100%; padding: 20px; }
        }
      `}</style>

      <div className="bg-white border-b sticky top-16 z-40 overflow-x-auto scrollbar-hide shadow-sm">
        <div className="max-w-7xl mx-auto px-4 flex items-center space-x-8">
          {[
            { id: 'home', label: 'ড্যাশবোর্ড', icon: <Zap size={18} /> },
            { id: 'records', label: 'প্রাপ্ত ফাইল ও রিপোর্ট', icon: <FileText size={18} /> },
            { id: 'notifications', label: 'এলার্ট', icon: <Bell size={18} /> },
            { id: 'storage', label: 'পার্সোনাল ক্লাউড', icon: <Cloud size={18} /> },
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveView(tab.id as any)} className={`py-5 px-1 text-sm font-bold flex items-center gap-2 border-b-2 transition-all whitespace-nowrap ${activeView === tab.id ? 'border-amber-600 text-amber-600' : 'border-transparent text-slate-500 hover:text-amber-500'}`}>
              {tab.icon} <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
        {activeView === 'home' && (
          <div className="space-y-12">
            <div className="bg-slate-900 rounded-[3.5rem] p-12 text-white relative overflow-hidden shadow-2xl border-4 border-slate-800">
              <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-amber-500/10 rounded-full blur-[100px]"></div>
              <div className="relative z-10 space-y-6">
                <div className="flex items-center gap-3">
                   <div className="px-4 py-1.5 bg-emerald-500 text-slate-900 rounded-full font-black text-[10px] uppercase flex items-center gap-2"><ShieldCheck size={14}/> Verified Identity</div>
                </div>
                <h2 className="text-5xl font-black leading-tight">স্বাগতম, <br/><span className="text-amber-500">{currentUser.name}</span></h2>
                <p className="text-slate-400 text-lg bengali-font max-w-xl">আপনার যাবতীয় ডকুমেন্ট এবং আপডেট এখন এক জায়গায় সুরক্ষিত।</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white p-10 rounded-[3rem] border shadow-xl">
                <h3 className="text-2xl font-black mb-8 flex items-center gap-3"><ListTodo className="text-amber-600" /> বর্তমান কাজ</h3>
                <div className="space-y-4">
                  {userTasks.length === 0 && <p className="text-center py-10 opacity-30 font-bold bengali-font">আপনার কোনো পেন্ডিং কাজ নেই।</p>}
                  {userTasks.map(t => (
                    <div key={t.id} className="p-6 bg-slate-50 border rounded-3xl flex items-center justify-between group hover:border-amber-400 transition-all">
                       <div>
                          <p className="font-black text-slate-800 bengali-font">{t.task}</p>
                          <p className="text-[10px] text-slate-400 font-bold uppercase">{t.status} • {t.createdAt}</p>
                       </div>
                       <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase ${t.priority === 'high' ? 'bg-rose-50 text-rose-500' : 'bg-slate-200 text-slate-600'}`}>{t.priority}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white p-10 rounded-[3rem] border shadow-xl">
                 <h3 className="text-2xl font-black mb-8 flex items-center gap-3"><Bell className="text-rose-500" /> নতুন এলার্ট</h3>
                 <div className="space-y-4">
                    {notifications.slice(0, 3).map(n => (
                      <div key={n.id} className="p-6 bg-rose-50/50 border border-rose-100 rounded-3xl animate-in slide-in-from-right-4">
                         <h4 className="font-black text-rose-600 text-sm mb-1">{n.title}</h4>
                         <p className="text-xs text-slate-600 bengali-font leading-relaxed">{n.message}</p>
                         <p className="text-[8px] font-bold text-slate-300 mt-2 uppercase">{n.timestamp}</p>
                      </div>
                    ))}
                    {notifications.length === 0 && <p className="text-center py-10 opacity-30 font-bold bengali-font">কোনো নতুন এলার্ট নেই।</p>}
                 </div>
              </div>
            </div>
          </div>
        )}

        {activeView === 'records' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4">
             <div className="flex items-center justify-between">
                <h3 className="text-3xl font-black bengali-font">আমার ডিজিটাল রিপোর্ট ও ফাইলসমূহ</h3>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Ownership Verified: {currentUser.phone}</p>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Office Documents Section */}
                {officeDocs.map(doc => (
                  <div key={doc.id} className="bg-white p-8 rounded-[3rem] border-2 border-transparent hover:border-amber-500 shadow-xl transition-all group">
                     <div className="flex items-center justify-between mb-6">
                        <div className="w-14 h-14 bg-amber-50 text-amber-500 rounded-2xl flex items-center justify-center"><FileText size={28}/></div>
                        <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase ${doc.status === 'verified' ? 'bg-emerald-500 text-white' : 'bg-amber-500 text-white animate-pulse'}`}>{doc.status === 'verified' ? 'ভেরিফাইড' : 'রিচেক চলছে'}</span>
                     </div>
                     <h4 className="font-black text-xl mb-2 text-slate-800">{doc.title}</h4>
                     <p className="text-xs text-slate-400 font-bold uppercase mb-6">Updated: {doc.lastModified}</p>
                     
                     <div className="grid grid-cols-3 gap-3">
                        <button onClick={() => setPreviewDoc(doc)} className="bg-slate-900 text-white py-3 rounded-xl text-[10px] font-black flex items-center justify-center gap-2 hover:bg-black"><Eye size={14}/> View</button>
                        <button onClick={() => requestRecheck(doc.id, 'doc')} className="bg-amber-50 text-amber-600 py-3 rounded-xl text-[10px] font-black flex items-center justify-center gap-2 hover:bg-amber-100"><RefreshCw size={14}/> Recheck</button>
                        <button onClick={() => { setPreviewDoc(doc); setTimeout(() => window.print(), 300); }} className="bg-slate-100 text-slate-600 py-3 rounded-xl text-[10px] font-black flex items-center justify-center gap-2 hover:bg-slate-200"><Printer size={14}/> Print</button>
                     </div>
                  </div>
                ))}

                {/* Manual Applications Section */}
                {applications.map(app => (
                  <div key={app.id} className="bg-white p-8 rounded-[3rem] border-2 border-transparent hover:border-blue-500 shadow-xl transition-all group">
                     <div className="flex items-center justify-between mb-6">
                        <div className="w-14 h-14 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center shadow-inner">
                           {app.source === 'scan' ? <Smartphone size={28}/> : <CheckCircle size={28}/>}
                        </div>
                        <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase ${app.status === 'Success' ? 'bg-emerald-500 text-white' : 'bg-amber-500 text-white'}`}>{app.status === 'Success' ? 'Success' : 'Pending'}</span>
                     </div>
                     <h4 className="font-black text-xl mb-2 text-slate-800 bengali-font">{app.applicationType}</h4>
                     <p className="text-xs text-slate-400 font-bold uppercase mb-1">ID: {app.trackingId}</p>
                     <p className="text-xs text-slate-400 font-bold mb-6">Date: {app.date}</p>
                     
                     <div className="grid grid-cols-3 gap-3">
                        <button onClick={() => setPreviewDoc(app)} className="bg-slate-900 text-white py-3 rounded-xl text-[10px] font-black flex items-center justify-center gap-2 hover:bg-black"><Eye size={14}/> Preview</button>
                        <button onClick={() => requestRecheck(app.id, 'app')} className="bg-amber-50 text-amber-600 py-3 rounded-xl text-[10px] font-black flex items-center justify-center gap-2 hover:bg-amber-100"><RefreshCw size={14}/> Fix Info</button>
                        <button onClick={() => { setPreviewDoc(app); setTimeout(() => window.print(), 300); }} className="bg-slate-100 text-slate-600 py-3 rounded-xl text-[10px] font-black flex items-center justify-center gap-2 hover:bg-slate-200"><Printer size={14}/> Print</button>
                     </div>
                  </div>
                ))}
             </div>

             {officeDocs.length === 0 && applications.length === 0 && (
               <div className="py-20 text-center bg-white rounded-[3rem] border border-dashed border-slate-200 opacity-30 select-none">
                  <FileText size={64} className="mx-auto mb-4" />
                  <p className="font-black text-xl bengali-font">এখনো কোনো প্রাপ্ত ডকুমেন্ট নেই</p>
               </div>
             )}
          </div>
        )}

        {activeView === 'notifications' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in slide-in-from-bottom-4">
             <div className="bg-white rounded-[3rem] border shadow-2xl overflow-hidden min-h-[500px]">
                <div className="p-8 border-b bg-slate-900 text-white font-black text-xl flex items-center gap-3"><Bell size={24} className="text-amber-500" /> নোটিফিকেশন সেন্টার</div>
                <div className="divide-y divide-slate-50">
                   {notifications.map(n => (
                     <div key={n.id} className="p-8 hover:bg-slate-50 transition-all flex items-start gap-6 group">
                        <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform"><Bell size={24}/></div>
                        <div>
                           <h4 className="font-black text-lg text-slate-800">{n.title}</h4>
                           <p className="text-sm text-slate-500 bengali-font mt-1 leading-relaxed">{n.message}</p>
                           <p className="text-[10px] font-bold text-slate-300 mt-3">{n.timestamp}</p>
                        </div>
                     </div>
                   ))}
                   {notifications.length === 0 && <div className="p-20 text-center opacity-30 font-black bengali-font">এখনো কোনো বার্তা আসেনি।</div>}
                </div>
             </div>
          </div>
        )}

        {activeView === 'storage' && currentUser && <CloudStorage user={currentUser} onUpdateUser={onUpdateUser} />}
      </div>

      {/* Modern Document Viewer for Customers */}
      {previewDoc && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xl animate-in fade-in">
           <div className="bg-white w-full max-w-4xl h-[90vh] rounded-[3rem] shadow-2xl overflow-hidden flex flex-col">
              <div className="p-8 border-b flex items-center justify-between bg-slate-50/50">
                 <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-amber-500 text-slate-900 rounded-2xl flex items-center justify-center font-black rotate-3">অ</div>
                    <div>
                       <h3 className="font-black text-xl bengali-font">{'title' in previewDoc ? previewDoc.title : previewDoc.applicationType}</h3>
                       <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Digital Record Viewer</p>
                    </div>
                 </div>
                 <button onClick={() => setPreviewDoc(null)} className="p-3 bg-white border rounded-2xl text-slate-400 hover:text-rose-500 transition-colors shadow-sm"><X size={24} /></button>
              </div>

              <div id="printable-record" className="flex-grow p-10 overflow-auto bg-slate-100/30">
                 <div className="max-w-2xl mx-auto bg-white p-12 shadow-2xl border min-h-[800px] rounded-xl flex flex-col">
                    {/* Header */}
                    <div className="text-center border-b-8 border-slate-900 pb-10 mb-10">
                       <h1 className="text-3xl font-black text-slate-900 mb-2 uppercase">মা অন্নপূর্ণা অনলাইন সার্ভিস</h1>
                       <p className="text-xs font-bold text-slate-500 bengali-font">রাজহাটী সিনেমাতলা মোড়, ২য় তল। Ph: 8145685318</p>
                    </div>

                    <div className="flex-grow space-y-6">
                       {/* App Content */}
                       {'applicationType' in previewDoc ? (
                         <div className="space-y-8">
                            <div className="grid grid-cols-2 gap-8 text-sm">
                               <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest bengali-font">গ্রাহক</label><p className="font-bold text-slate-800">{previewDoc.customerName}</p></div>
                               <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest bengali-font">আইডি</label><p className="font-bold text-slate-800">#{previewDoc.trackingId}</p></div>
                               <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest bengali-font">ধরণ</label><p className="font-bold text-slate-800 bengali-font">{previewDoc.applicationType}</p></div>
                               <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest bengali-font">তারিখ</label><p className="font-bold text-slate-800">{previewDoc.date}</p></div>
                            </div>
                            <div className="p-8 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 min-h-[300px] flex items-center justify-center">
                               {previewDoc.fileData ? (
                                 <img src={previewDoc.fileData} className="max-w-full rounded-lg shadow-lg" alt="Record" />
                               ) : (
                                 <div className="text-center opacity-20"><FileText size={64} className="mx-auto mb-2" /><p className="font-black bengali-font">ইমেজ প্রিভিউ নেই</p></div>
                               )}
                            </div>
                         </div>
                       ) : (
                         /* Office Doc Content */
                         <div className="space-y-6">
                            <h2 className="text-2xl font-black text-center mb-8 underline underline-offset-8 decoration-amber-500">{previewDoc.title}</h2>
                            {previewDoc.type === 'excel' ? (
                               <div className="border border-slate-300 rounded overflow-hidden">
                                  <table className="w-full border-collapse">
                                     <tbody>
                                        {(previewDoc.content as string[][]).map((row, r) => (
                                          <tr key={r}>
                                             {row.map((cell, c) => (
                                               <td key={c} className="border border-slate-300 p-3 text-sm font-bold text-slate-700">{cell}</td>
                                             ))}
                                          </tr>
                                        ))}
                                     </tbody>
                                  </table>
                               </div>
                            ) : (
                               <p className="text-lg leading-relaxed font-bold text-slate-700 bengali-font whitespace-pre-wrap">{previewDoc.content}</p>
                            )}
                         </div>
                       )}
                    </div>

                    <div className="mt-20 pt-10 border-t flex justify-between items-end">
                       <p className="text-[8px] font-black uppercase text-slate-300 tracking-widest">Ma Annapurna Digital Records</p>
                       <div className="text-center"><div className="w-24 border-b border-slate-300 mb-2"></div><p className="text-[8px] font-black uppercase text-slate-400">Authorized Signature</p></div>
                    </div>
                 </div>
              </div>

              <div className="p-8 border-t flex items-center justify-center gap-4 bg-slate-50/50">
                 <button onClick={() => window.print()} className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-black flex items-center gap-2 shadow-xl hover:scale-105 transition-all"><Printer size={20}/> Print Report</button>
                 <button className="bg-white border-2 border-slate-900 text-slate-900 px-10 py-4 rounded-2xl font-black flex items-center gap-2 hover:bg-slate-50 transition-all"><Download size={20}/> Download PDF</button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default UserPanel;
