
import React, { useState } from 'react';
import { X, Lock, User as UserIcon, ShieldCheck, ArrowRight, Loader2, ShieldAlert, Smartphone } from 'lucide-react';
import { User } from '../types';

interface UserAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: User) => void;
}

const UserAuthModal: React.FC<UserAuthModalProps> = ({ isOpen, onClose, onAuthSuccess }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [formData, setFormData] = useState({ 
    name: '', 
    phone: '', 
    password: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Simulate network delay
    setTimeout(() => {
      const users: User[] = JSON.parse(localStorage.getItem('ma_users') || '[]');
      const cleanPhone = formData.phone.trim().replace(/\s/g, '');

      if (mode === 'login') {
        const found = users.find(u => u.phone === cleanPhone && u.password === formData.password);
        if (found) {
          onAuthSuccess(found);
          reset();
        } else {
          setError('ভুল ফোন নাম্বার বা পাসওয়ার্ড!');
        }
      } else {
        if (users.some(u => u.phone === cleanPhone)) {
          setError('এই ফোন নাম্বারে ইতিমধ্যে অ্যাকাউন্ট আছে।');
        } else {
          const newUser: User = {
            id: Date.now().toString(),
            name: formData.name.trim(),
            phone: cleanPhone,
            isVerified: true,
            password: formData.password,
            role: 'user',
            joinedDate: new Date().toISOString(),
            storageUsed: 0,
            files: []
          };
          
          const updatedUsers = [...users, newUser];
          localStorage.setItem('ma_users', JSON.stringify(updatedUsers));
          onAuthSuccess(newUser);
          reset();
        }
      }
      setLoading(false);
    }, 800);
  };

  const reset = () => {
    setFormData({ name: '', phone: '', password: '' });
    setError('');
    setMode('login');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden relative">
        <button onClick={onClose} className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-900 transition-colors bg-slate-100 rounded-full z-10">
          <X size={20} />
        </button>

        <div className="bg-slate-900 p-8 text-white text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
          <div className="w-14 h-14 bg-amber-500 rounded-2xl flex items-center justify-center mx-auto mb-3 rotate-3 shadow-lg">
            <ShieldCheck size={28} className="text-slate-900" />
          </div>
          <h2 className="text-xl font-black bengali-font">
            {mode === 'login' ? 'নিরাপদ প্রবেশ' : 'নতুন অ্যাকাউন্ট তৈরি'}
          </h2>
          <p className="text-slate-400 text-[10px] mt-1 uppercase tracking-widest opacity-80">Identity Protection Secured</p>
        </div>

        <div className="p-8">
          {error && (
            <div className="mb-6 p-4 bg-rose-50 text-rose-600 rounded-2xl text-xs bengali-font flex items-center gap-3 border border-rose-100 animate-in shake">
              <ShieldAlert size={18} /> 
              <strong>{error}</strong>
            </div>
          )}
          
          <form onSubmit={handleAuthSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                  type="text" 
                  placeholder="আপনার পুরো নাম" 
                  required 
                  className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 outline-none bengali-font focus:ring-2 focus:ring-amber-500 font-bold" 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})} 
                />
              </div>
            )}
            
            <div className="relative">
              <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
              <input 
                type="tel" 
                placeholder="ফোন নাম্বার" 
                required 
                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 outline-none focus:ring-2 focus:ring-amber-500 font-bold" 
                value={formData.phone} 
                onChange={e => setFormData({...formData, phone: e.target.value})} 
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
              <input 
                type="password" 
                placeholder="পাসওয়ার্ড" 
                required 
                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 outline-none focus:ring-2 focus:ring-amber-500 font-bold" 
                value={formData.password} 
                onChange={e => setFormData({...formData, password: e.target.value})} 
              />
            </div>

            <button 
              type="submit" 
              disabled={loading} 
              className="w-full bg-slate-900 hover:bg-black text-white py-5 rounded-2xl font-black bengali-font shadow-xl flex items-center justify-center space-x-2 transition-all active:scale-95"
            >
              {loading ? (
                <Loader2 className="animate-spin" />
              ) : (
                <>
                  <span>{mode === 'login' ? 'লগইন করুন' : 'অ্যাকাউন্ট তৈরি করুন'}</span> 
                  <ArrowRight size={18} />
                </>
              )}
            </button>

            <div className="mt-6 text-center">
              <button 
                type="button" 
                onClick={() => {
                  setMode(mode === 'login' ? 'signup' : 'login');
                  setError('');
                }} 
                className="text-amber-600 font-bold text-xs bengali-font hover:underline"
              >
                {mode === 'login' ? 'অ্যাকাউন্ট নেই? নতুন তৈরি করুন' : 'ইতিমধ্যে অ্যাকাউন্ট আছে? লগইন করুন'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default UserAuthModal;
