
import React, { useState } from 'react';
import { Sparkles, Copy, RefreshCw, Send, Share2, Facebook, MessageCircle, CheckCircle } from 'lucide-react';
import { generatePromoPost } from '../services/geminiService';
import { SERVICES } from '../constants';

const AICreativeStudio: React.FC = () => {
  const [selectedService, setSelectedService] = useState(SERVICES[0].title);
  const [generatedText, setGeneratedText] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    setCopied(false);
    const text = await generatePromoPost(selectedService);
    setGeneratedText(text || '');
    setLoading(false);
  };

  const copyToClipboard = () => {
    if (!generatedText) return;
    navigator.clipboard.writeText(generatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareToWhatsApp = () => {
    if (!generatedText) return;
    window.open(`https://wa.me/?text=${encodeURIComponent(generatedText)}`, '_blank');
  };

  return (
    <div className="animate-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-amber-100 p-2 rounded-xl text-amber-600">
              <Sparkles size={24} />
            </div>
            <h3 className="text-xl font-bold bengali-font">AI প্রমোশন মেকার</h3>
          </div>
          
          <p className="text-sm text-slate-500 mb-8 bengali-font">
            আপনার ব্যবসার প্রমোশনের জন্য অটোমেটিক বিজ্ঞাপনের টেক্সট তৈরি করুন। নিচে থেকে আপনার একটি পরিষেবা নির্বাচন করুন।
          </p>

          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 bengali-font">পরিষেবা নির্বাচন করুন</label>
              <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                {SERVICES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSelectedService(s.title)}
                    className={`text-left p-4 rounded-xl border transition-all text-sm bengali-font ${
                      selectedService === s.title 
                      ? 'bg-amber-50 border-amber-500 text-amber-700 font-bold ring-2 ring-amber-100' 
                      : 'bg-white border-slate-100 text-slate-600 hover:border-amber-200'
                    }`}
                  >
                    {s.title}
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={handleGenerate}
              disabled={loading}
              className={`w-full py-4 rounded-xl font-bold flex items-center justify-center space-x-2 shadow-lg transition-all active:scale-95 ${
                loading ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-amber-600 to-amber-500 text-white hover:shadow-amber-200'
              }`}
            >
              {loading ? <RefreshCw className="animate-spin" size={20} /> : <Sparkles size={20} />}
              <span className="bengali-font">{loading ? 'জেনারেট হচ্ছে...' : 'প্রমোশন টেক্সট তৈরি করুন'}</span>
            </button>
          </div>
        </div>

        {/* Output Section */}
        <div className="flex flex-col h-full">
          {generatedText ? (
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex-grow flex flex-col">
              <div className="flex justify-between items-center mb-6">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest bengali-font">আপনার প্রমোশনাল টেক্সট:</span>
                <button 
                  onClick={copyToClipboard}
                  className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    copied ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                  }`}
                >
                  {copied ? <CheckCircle size={14} /> : <Copy size={14} />}
                  <span>{copied ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl flex-grow font-sans text-sm leading-relaxed text-slate-700 whitespace-pre-wrap bengali-font border border-slate-100 overflow-y-auto max-h-[400px]">
                {generatedText}
              </div>

              <div className="mt-8 pt-8 border-t border-slate-50 grid grid-cols-2 gap-4">
                <button className="bg-[#1877F2] text-white py-3 rounded-xl flex items-center justify-center space-x-2 font-bold text-sm hover:opacity-90 transition-opacity">
                  <Facebook size={18} />
                  <span>Facebook</span>
                </button>
                <button onClick={shareToWhatsApp} className="bg-[#25D366] text-white py-3 rounded-xl flex items-center justify-center space-x-2 font-bold text-sm hover:opacity-90 transition-opacity">
                  <MessageCircle size={18} />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-100/50 border-2 border-dashed border-slate-200 rounded-3xl flex-grow flex flex-col items-center justify-center p-12 text-center opacity-60">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-slate-300 mb-6 shadow-sm">
                <Sparkles size={32} />
              </div>
              <h4 className="font-bold text-slate-400 bengali-font">কোনো টেক্সট জেনারেট করা নেই</h4>
              <p className="text-xs text-slate-400 max-w-xs mt-2 bengali-font">উপরে পরিষেবা নির্বাচন করে বাটন ক্লিক করলে এখানে ম্যাজিক দেখতে পাবেন!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AICreativeStudio;
