
import React, { useState, useRef } from 'react';
import { User } from '../types';
import { User as UserIcon, Calendar, ShieldCheck, Phone, CheckCircle, Save, Lock, Camera, Mail, KeyRound, AlertCircle } from 'lucide-react';

interface UserDashboardProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
}

const UserDashboard: React.FC<UserDashboardProps> = ({ user, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'security'>('profile');
  const [isEditing, setIsEditing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email || '',
    phone: user.phone
  });

  const [passData, setPassData] = useState({
    current: '',
    new: '',
    confirm: ''
  });
  const [showPass, setShowPass] = useState(false);
  const [saveStatus, setSaveStatus] = useState(false);
  const [error, setError] = useState('');

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      ...user,
      name: formData.name,
      email: formData.email,
      phone: formData.phone
    });
    setSaveStatus(true);
    setIsEditing(false);
    setTimeout(() => setSaveStatus(false), 2000);
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (passData.current !== user.password) {
      setError('বর্তমান পাসওয়ার্ড ভুল!');
      return;
    }
    if (passData.new !== passData.confirm) {
      setError('নতুন পাসওয়ার্ড দুটি মিলছে না!');
      return;
    }
    if (passData.new.length < 6) {
      setError('পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে।');
      return;
    }

    onUpdateUser({ ...user, password: passData.new });
    setSaveStatus(true);
    setPassData({ current: '', new: '', confirm: '' });
    setTimeout(() => setSaveStatus(false), 2000);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpdateUser({
          ...user,
          profilePicture: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
      {/* Profile Summary Card */}
      <div className="bg-white rounded-[3rem] p-10 shadow-xl border border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-50 rounded-full -mr-24 -mt-24 opacity-50 z-0"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
          <div className="relative group">
            <div className="w-40 h-40 bg-slate-900 rounded-[2.5rem] flex items-center justify-center text-white text-6xl font-black shadow-2xl border-8 border-white overflow-hidden ring-4 ring-slate-50">
              {user.profilePicture ? <img src={user.profilePicture} className="w-full h-full object-cover" /> : user.name.charAt(0)}
            </div>
            <button onClick={() => fileInputRef.current?.click()} className="absolute -bottom-2 -right-2 p-4 bg-amber-600 text-white rounded-2xl shadow-xl hover:bg-slate-900 transition-all scale-95 group-hover:scale-100"><Camera size={20} /></button>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload} />
          </div>

          <div className="text-center md:text-left space-y-3">
            <div className="flex flex-col md:flex-row items-center gap-3">
              <h2 className="text-4xl font-black text-slate-800 bengali-font leading-tight">{user.name}</h2>
              <span className="bg-emerald-100 text-emerald-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2 border border-emerald-200 shadow-sm">
                <ShieldCheck size={14} /> ভেরিফাইড ইউজার
              </span>
            </div>
            <div className="flex flex-wrap justify-center md:justify-start items-center gap-4 text-slate-400 font-bold text-sm">
              <p className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-xl border"><Phone size={16} className="text-amber-600" /> {user.phone}</p>
              {user.email && <p className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-xl border"><Mail size={16} className="text-amber-600" /> {user.email}</p>}
              <p className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-xl border"><Calendar size={16} className="text-amber-600" /> {new Date(user.joinedDate).toLocaleDateString('bn-BD')}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-white p-1.5 rounded-2xl border shadow-sm w-fit mx-auto md:mx-0">
        <button onClick={() => setActiveTab('profile')} className={`px-10 py-3 rounded-xl text-sm font-black bengali-font transition-all ${activeTab === 'profile' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>প্রোফাইল</button>
        <button onClick={() => setActiveTab('security')} className={`px-10 py-3 rounded-xl text-sm font-black bengali-font transition-all ${activeTab === 'security' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>নিরাপত্তা</button>
      </div>

      {activeTab === 'profile' ? (
        <div className="bg-white rounded-[3rem] border shadow-2xl overflow-hidden animate-in slide-in-from-left-4">
          <div className="p-10 border-b flex items-center justify-between bg-slate-50/50">
            <h3 className="text-2xl font-black bengali-font flex items-center gap-3 text-slate-800"><UserIcon className="text-amber-600" /> অ্যাকাউন্ট ডিটেইলস</h3>
            <button onClick={() => setIsEditing(!isEditing)} className="bg-white border px-6 py-2 rounded-xl text-slate-600 font-bold text-sm bengali-font hover:bg-slate-50 shadow-sm">
              {isEditing ? 'বাতিল' : 'তথ্য পরিবর্তন'}
            </button>
          </div>
          <div className="p-10 max-w-3xl">
            <form onSubmit={handleProfileSave} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">আপনার নাম</label>
                  <input type="text" disabled={!isEditing} className="w-full p-5 rounded-2xl bg-slate-50 border outline-none font-bold bengali-font disabled:opacity-50 focus:ring-2 focus:ring-amber-500" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">ইমেইল</label>
                  <input type="email" disabled={!isEditing} className="w-full p-5 rounded-2xl bg-slate-50 border outline-none font-bold disabled:opacity-50 focus:ring-2 focus:ring-amber-500" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
                </div>
              </div>
              {isEditing && (
                <button type="submit" className="bg-slate-900 text-white px-10 py-5 rounded-2xl font-black bengali-font shadow-xl hover:bg-black transition-all flex items-center gap-2">
                  <CheckCircle size={20} /> সেভ করুন
                </button>
              )}
              {saveStatus && !isEditing && (
                <div className="flex items-center gap-2 text-emerald-600 font-bold bengali-font animate-in slide-in-from-left-2">
                  <CheckCircle size={18} /> প্রোফাইল আপডেট হয়েছে!
                </div>
              )}
            </form>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-[3rem] border shadow-2xl overflow-hidden animate-in slide-in-from-right-4">
          <div className="p-10 border-b flex items-center justify-between bg-slate-50/50">
            <h3 className="text-2xl font-black bengali-font flex items-center gap-3 text-slate-800"><KeyRound className="text-amber-600" /> পাসওয়ার্ড পরিবর্তন</h3>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]"><ShieldCheck className="inline mr-1"/> Secure Access</span>
          </div>
          <div className="p-10 max-w-2xl">
            {error && <div className="mb-6 p-4 bg-rose-50 text-rose-600 rounded-2xl flex items-center gap-3 border border-rose-100 font-bold text-sm bengali-font"><AlertCircle size={20} /> {error}</div>}
            <form onSubmit={handlePasswordChange} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">বর্তমান পাসওয়ার্ড</label>
                <div className="relative">
                  <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
                  <input type="password" required className="w-full pl-14 pr-4 py-5 rounded-2xl bg-slate-50 border outline-none font-bold focus:ring-2 focus:ring-slate-900" value={passData.current} onChange={e => setPassData({...passData, current: e.target.value})} />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">নতুন পাসওয়ার্ড</label>
                  <input type="password" required className="w-full p-5 rounded-2xl bg-slate-50 border outline-none font-bold focus:ring-2 focus:ring-slate-900" value={passData.new} onChange={e => setPassData({...passData, new: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">পুনরায় দিন</label>
                  <input type="password" required className="w-full p-5 rounded-2xl bg-slate-50 border outline-none font-bold focus:ring-2 focus:ring-slate-900" value={passData.confirm} onChange={e => setPassData({...passData, confirm: e.target.value})} />
                </div>
              </div>
              <button type="submit" className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black bengali-font shadow-xl hover:bg-black transition-all flex items-center justify-center gap-3">
                <Save size={20} /> পাসওয়ার্ড আপডেট করুন
              </button>
              {saveStatus && (
                <p className="text-emerald-600 font-black text-sm text-center bengali-font animate-in fade-in">পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে!</p>
              )}
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserDashboard;
