
import React from 'react';
import { 
  FileText, 
  CreditCard, 
  Map, 
  GraduationCap, 
  Briefcase, 
  ShieldCheck, 
  Printer, 
  Image as ImageIcon,
  Gavel,
  History,
  Scale,
  Search
} from 'lucide-react';
import { ServiceItem, Feedback } from './types';

export const BUSINESS_INFO = {
  name: "মা অন্নপূর্ণা অনলাইন সার্ভিস",
  englishName: "Ma Annapurna Online Service",
  slogan: "আপনার আস্থাই আমাদের পরিচয়",
  proprietor: "ভবাণী ব্যানার্জী",
  address: "রাজহাটী, গুইরাম হাজরা ভ্যারাইটি স্টোর, ২য় তল।",
  phones: ["8145685318", "9734420340"],
  whatsapp: "8145685318",
  locationLink: "https://maps.google.com/?q=Rajhati+Cinematala+Crossing"
};

export const SERVICES: ServiceItem[] = [
  {
    id: '1',
    title: 'জেরক্স ও ফটো',
    category: 'Xerox & Photos',
    description: 'কালার ও বি/ডব্লিউ জেরক্স, ল্যামিনেশন এবং পাসপোর্ট সাইজ ফটো।',
    icon: 'Printer'
  },
  {
    id: '7',
    title: 'মিউটেশন ও রেকর্ড',
    category: 'Land Services',
    description: 'জমির মিউটেশন, রেকর্ড সংশোধন এবং ডিজিটাল পর্চা (ROR) সার্চিং।',
    icon: 'Map'
  },
  {
    id: '8',
    title: 'রেজিস্ট্রি ও দলিল',
    category: 'Legal Documents',
    description: 'জমির রেজিস্ট্রি, দানপত্র দলিল (Gift Deed) ও বয়না পত্রের ড্রাফটিং।',
    icon: 'Gavel'
  },
  {
    id: '9',
    title: 'দানপত্র দলিল',
    category: 'Legal Documents',
    description: 'নির্ভুলভাবে দানপত্র দলিল প্রস্তুত ও অনলাইন সাবমিশন।',
    icon: 'Scale'
  },
  {
    id: '2',
    title: 'সরকারি আইডি',
    category: 'Government IDs',
    description: 'নতুন ভোটার কার্ড, প্যান কার্ড, রেশন কার্ড আবেদন ও সংশোধন।',
    icon: 'CreditCard'
  },
  {
    id: '3',
    title: 'সার্টিফিকেট',
    category: 'Certificates',
    description: 'বিডিও/এসডিও ইনকাম, রেসিডেন্স এবং কাস্ট সার্টিফিকেট।',
    icon: 'FileText'
  },
  {
    id: '5',
    title: 'শিক্ষা ও ক্যারিয়ার',
    category: 'Education',
    description: 'স্কুল/কলেজ ফর্ম ফিলাপ, প্রজেক্ট, স্কলারশিপ এবং যুবশ্রী রেজিস্ট্রেশন।',
    icon: 'GraduationCap'
  },
  {
    id: '6',
    title: 'ব্যবসা সংক্রান্ত',
    category: 'Business',
    description: 'ট্রেড লাইসেন্স, ডিজিটাল রেজিস্ট্রেশন এবং প্রফেশনাল ডকুমেন্টেশন।',
    icon: 'Briefcase'
  }
];

export const INITIAL_FEEDBACK: Feedback[] = [
  {
    id: '1',
    name: 'সুজিত বিশ্বাস',
    service: 'জমির মিউটেশন',
    rating: 5,
    comment: 'খুব তাড়াতাড়ি কাজ হয়েছে। দাদাদের ব্যবহার খুব ভালো।',
    date: '২০ মে ২০২৪',
    status: 'approved'
  },
  {
    id: '2',
    name: 'অনুপম সরকার',
    service: 'প্যান কার্ড',
    rating: 5,
    comment: 'ভবাণী বাবুর সার্ভিস সবসময়ই সেরা। নির্ভুল কাজ।',
    date: '২২ মে ২০২৪',
    status: 'approved'
  }
];

export const getIcon = (name: string) => {
  switch (name) {
    case 'Printer': return <Printer className="w-6 h-6" />;
    case 'CreditCard': return <CreditCard className="w-6 h-6" />;
    case 'FileText': return <FileText className="w-6 h-6" />;
    case 'Map': return <Map className="w-6 h-6" />;
    case 'GraduationCap': return <GraduationCap className="w-6 h-6" />;
    case 'Briefcase': return <Briefcase className="w-6 h-6" />;
    case 'Gavel': return <Gavel className="w-6 h-6" />;
    case 'Scale': return <Scale className="w-6 h-6" />;
    case 'Search': return <Search className="w-6 h-6" />;
    default: return <ShieldCheck className="w-6 h-6" />;
  }
};
