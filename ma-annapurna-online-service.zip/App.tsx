
import React, { useState, useEffect } from 'react';
import { AppView, Feedback, User, AppAlert, AppNotification } from './types.ts';
import UserPanel from './components/UserPanel.tsx';
import AdminPanel from './components/AdminPanel.tsx';
import AdminLogin from './components/AdminLogin.tsx';
import UserAuthModal from './components/UserAuthModal.tsx';
import AIChatBot from './components/AIChatBot.tsx';
import { BUSINESS_INFO, INITIAL_FEEDBACK } from './constants.tsx';
import { User as UserIcon, Settings, Phone, Menu, X, LogOut, Search, Bell, Globe, MessageCircle, Heart } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.USER);
  const [lang, setLang] = useState<'bn' | 'en'>(() => (localStorage.getItem('ma_lang') as any) || 'bn');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>(INITIAL_FEEDBACK);
  const [unreadCount, setUnreadCount] = useState(0);
  
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('ma_admin_auth') === 'true';
  });
  
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('ma_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [alerts, setAlerts] = useState<AppAlert[]>([
    { id: '1', message: 'নতুন রেশন কার্ড আবেদন শুরু হয়েছে। আজই যোগাযোগ করুন!', type: 'info', priority: 'medium', date: '২০ মে', active: true }
  ]);

  const updateUnreadCount = () => {
    if (currentUser) {
      const allNotifs: AppNotification[] = JSON.parse(localStorage.getItem('ma_notifications') || '[]');
      const count = allNotifs.filter(n => n.targetPhone === currentUser.phone && !n.isRead).length;
      setUnreadCount(count);
    } else {
      setUnreadCount(0);
    }
  };

  useEffect(() => {
    updateUnreadCount();
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'ma_current_user') {
        const user = e.newValue ? JSON.parse(e.newValue) : null;
        setCurrentUser(user);
        updateUnreadCount();
      }
      if (e.key === 'ma_admin_auth') {
        setIsAuthenticated(e.newValue === 'true');
      }
      if (e.key === 'ma_notifications') {
        updateUnreadCount();
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('ma_lang', lang);
  }, [lang]);

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('ma_current_user');
    setView(AppView.USER);
    setIsMenuOpen(false);
  };

  const handleAdminLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('ma_admin_auth');
    localStorage.removeItem('ma_active_admin_id');
    setView(AppView.ADMIN);
    setIsMenuOpen(false);
  };

  const updateUser = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    localStorage.setItem('ma_current_user', JSON.stringify(updatedUser));
    const allUsers = JSON.parse(localStorage.getItem('ma_users') || '[]');
    const userIndex = allUsers.findIndex((u: User) => u.phone === updatedUser.phone);
    if (userIndex !== -1) { 
      allUsers[userIndex] = updatedUser; 
      localStorage.setItem('ma_users', JSON.stringify(allUsers)); 
    }
  };

  const navigateTo = (newView: AppView) => {
    setView(newView);
    setIsMenuOpen(false);
  };

  const toggleLang = () => {
    setLang(prev => prev === 'bn' ? 'en' : 'bn');
  };

  const t = {
    home: lang === 'bn' ? 'হোম' : 'Home',
    login: lang === 'bn' ? 'লগইন' : 'Login',
    admin: lang === 'bn' ? 'অ্যাডমিন' : 'Admin',
    call: lang === 'bn' ? 'কল করুন' : 'Call Now',
    portal: lang === 'bn' ? 'ডিজিটাল পোর্টাল' : 'Digital Portal',
    langName: lang === 'bn' ? 'English' : 'বাংলা',
    proprietor: lang === 'bn' ? 'পরিচালক' : 'Proprietor'
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans bg-slate-50 ${lang === 'bn' ? 'bengali-font' : ''}`}>
      {alerts.filter(a => a.active).slice(0, 1).map(alert => (
        <div key={alert.id} className={`${alert.priority === 'high' ? 'bg-rose-600' : 'bg-amber-600'} text-white py-2 px-4 text-center text-sm font-medium flex items-center justify-center space-x-2 z-[60]`}>
          <Bell size={14} className="animate-bounce" />
          <span>{alert.message}</span>
        </div>
      ))}

      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 cursor-pointer group" onClick={() => navigateTo(AppView.USER)}>
              <div className="w-10 h-10 bg-amber-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg ring-2 ring-amber-100 group-hover:scale-105 transition-transform">
                {lang === 'bn' ? 'অ' : 'A'}
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-amber-700 leading-tight">{BUSINESS_INFO.name}</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest leading-tight">{t.portal}</span>
              </div>
            </div>

            <nav className="hidden md:flex items-center space-x-6">
              <button onClick={toggleLang} className="flex items-center space-x-2 text-xs font-black text-slate-400 hover:text-amber-600 px-3 py-1.5 border rounded-full transition-all">
                <Globe size={14} />
                <span>{t.langName}</span>
              </button>

              <button onClick={() => navigateTo(AppView.USER)} className={`flex items-center space-x-2 text-sm font-medium transition-colors ${view === AppView.USER ? 'text-amber-600' : 'text-slate-600 hover:text-amber-600'}`}>
                <Search size={18} />
                <span>{t.home}</span>
              </button>
              
              {!currentUser ? (
                <button onClick={() => setIsAuthModalOpen(true)} className="flex items-center space-x-2 text-sm font-medium text-slate-600 hover:text-amber-600 transition-colors"><UserIcon size={18} /><span>{t.login}</span></button>
              ) : (
                <div className="flex items-center space-x-3 bg-slate-100 pl-1.5 pr-3 py-1.5 rounded-full border relative">
                  <div className="w-7 h-7 bg-amber-500 rounded-full overflow-hidden flex items-center justify-center text-white text-[10px] font-black">
                    {currentUser.profilePicture ? (
                      <img src={currentUser.profilePicture} alt={currentUser.name} className="w-full h-full object-cover" />
                    ) : (
                      currentUser.name.charAt(0)
                    )}
                  </div>
                  <span className="text-sm font-bold text-slate-700 max-w-[100px] truncate">{currentUser.name}</span>
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -left-1 bg-rose-500 text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-bounce border-2 border-white shadow-sm">{unreadCount}</span>
                  )}
                  <button onClick={handleLogout} className="text-slate-400 hover:text-rose-500 transition-colors"><LogOut size={16} /></button>
                </div>
              )}
              
              <button onClick={() => navigateTo(AppView.ADMIN)} className={`flex items-center space-x-2 text-sm font-medium transition-colors ${view === AppView.ADMIN ? 'text-amber-600' : 'text-slate-600 hover:text-amber-600'}`}><Settings size={18} /><span>{t.admin}</span></button>
              <a href={`tel:${BUSINESS_INFO.phones[0]}`} className="bg-slate-900 text-white px-5 py-2.5 rounded-full text-sm font-semibold flex items-center space-x-2 transition-all shadow-md hover:scale-105"><Phone size={16} /><span>{t.call}</span></a>
            </nav>
            
            <button className="md:hidden text-slate-600 p-2 hover:bg-slate-100 rounded-lg transition-colors relative" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {unreadCount > 0 && <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white"></span>}
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-16 left-0 w-full bg-white border-b shadow-2xl animate-in slide-in-from-top duration-300 z-50">
            <div className="px-4 py-6 space-y-4">
              <button onClick={toggleLang} className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                 <div className="flex items-center gap-3 text-slate-600 font-bold">
                    <Globe size={20} />
                    <span>{lang === 'bn' ? 'Switch to English' : 'বাংলা ভাষায় দেখুন'}</span>
                 </div>
                 <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-[10px] font-black">{t.langName}</span>
              </button>

              <button 
                onClick={() => navigateTo(AppView.USER)} 
                className={`w-full flex items-center space-x-4 p-4 rounded-2xl transition-all ${view === AppView.USER ? 'bg-amber-50 text-amber-600' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <Search size={24} />
                <span className="text-lg font-bold">{t.home}</span>
              </button>

              {!currentUser ? (
                <button 
                  onClick={() => { setIsAuthModalOpen(true); setIsMenuOpen(false); }} 
                  className="w-full flex items-center space-x-4 p-4 rounded-2xl text-slate-600 hover:bg-slate-50 transition-all"
                >
                  <UserIcon size={24} />
                  <span className="text-lg font-bold">{t.login}</span>
                </button>
              ) : (
                <div className="p-4 bg-slate-50 rounded-2xl">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-amber-500 rounded-full overflow-hidden flex items-center justify-center text-white font-black relative">
                        {currentUser.profilePicture ? (
                          <img src={currentUser.profilePicture} alt={currentUser.name} className="w-full h-full object-cover" />
                        ) : (
                          currentUser.name.charAt(0)
                        )}
                        {unreadCount > 0 && <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[8px] flex items-center justify-center rounded-full border-2 border-white">{unreadCount}</span>}
                      </div>
                      <span className="text-lg font-bold text-slate-700">{currentUser.name}</span>
                    </div>
                    <button onClick={handleLogout} className="text-rose-500 p-2 bg-rose-50 rounded-xl"><LogOut size={20} /></button>
                  </div>
                </div>
              )}

              <button 
                onClick={() => navigateTo(AppView.ADMIN)} 
                className={`w-full flex items-center space-x-4 p-4 rounded-2xl transition-all ${view === AppView.ADMIN ? 'bg-amber-50 text-amber-600' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <Settings size={24} />
                <span className="text-lg font-bold">{t.admin}</span>
              </button>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <a href={`tel:${BUSINESS_INFO.phones[0]}`} className="bg-slate-900 text-white p-4 rounded-2xl font-bold flex flex-col items-center justify-center space-y-2 shadow-lg">
                  <Phone size={24} />
                  <span className="text-sm">{t.call}</span>
                </a>
                <a href={`https://wa.me/91${BUSINESS_INFO.whatsapp}`} target="_blank" rel="noopener noreferrer" className="bg-emerald-500 text-white p-4 rounded-2xl font-bold flex flex-col items-center justify-center space-y-2 shadow-lg">
                  <MessageCircle size={24} />
                  <span className="text-sm">WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </header>

      <main className="flex-grow relative">
        {view === AppView.USER ? (
          <UserPanel lang={lang} currentUser={currentUser} onUpdateUser={updateUser} onOpenAuth={() => setIsAuthModalOpen(true)} />
        ) : (
          isAuthenticated ? (
            <AdminPanel lang={lang} onLogout={handleAdminLogout} />
          ) : (
            <AdminLogin onLogin={(s) => { setIsAuthenticated(s); localStorage.setItem('ma_admin_auth', 'true'); }} onCancel={() => setView(AppView.USER)} />
          )
        )}
        
        <AIChatBot />
      </main>

      <UserAuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} onAuthSuccess={(u) => { setCurrentUser(u); localStorage.setItem('ma_current_user', JSON.stringify(u)); setIsAuthModalOpen(false); }} />

      <footer className="bg-slate-900 text-slate-300 py-16 mt-auto no-print">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h3 className="text-white font-black text-2xl mb-2">{BUSINESS_INFO.name}</h3>
          <p className="text-amber-500 font-bold mb-6 bengali-font tracking-wide">“{BUSINESS_INFO.slogan}”</p>
          
          <div className="max-w-md mx-auto p-6 bg-white/5 rounded-[2rem] border border-white/10 mb-8">
            <p className="text-xs font-black uppercase text-slate-500 tracking-[0.3em] mb-3">{t.proprietor}</p>
            <h4 className="text-xl font-black text-white bengali-font">{BUSINESS_INFO.proprietor}</h4>
          </div>

          <p className="text-sm opacity-60 leading-relaxed mb-4">{BUSINESS_INFO.address}</p>
          <div className="pt-8 border-t border-slate-800 text-[10px] opacity-40 font-bold tracking-widest">&copy; {new Date().getFullYear()} {BUSINESS_INFO.englishName} • {t.proprietor}: BHABANI BANERJEE</div>
        </div>
      </footer>

      {isMenuOpen && (
        <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 md:hidden" onClick={() => setIsMenuOpen(false)}></div>
      )}
    </div>
  );
};

export default App;
